import { Request, Response, NextFunction } from 'express';
import { AnyZodObject, ZodError } from 'zod';

export const validateRequest = (schema: AnyZodObject) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await schema.parseAsync({
        body: req.body,
        query: req.query,
        params: req.params
      });
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          success: false,
          message: 'Error de validación en los datos enviados',
          errors: error.errors.map(e => ({
            field: e.path.join('.').replace('body.', '').replace('query.', '').replace('params.', ''),
            message: e.message
          }))
        });
        return;
      }
      res.status(500).json({ success: false, message: 'Error interno de validación' });
    }
  };
};
