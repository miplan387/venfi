"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const settingsController_1 = require("../controllers/settingsController");
const authMiddleware_1 = require("../middleware/authMiddleware");
const adminMiddleware_1 = require("../middleware/adminMiddleware");
const router = (0, express_1.Router)();
// 1. Obtener la configuración actual de métodos de pago (Público)
router.get('/payments', (req, res) => {
    settingsController_1.settingsController.getPaymentSettings(req, res);
});
// 2. Actualizar configuración de un método de pago específico (Admin)
router.put('/payments/:key', authMiddleware_1.optionalAuthMiddleware, adminMiddleware_1.requireAdmin, (req, res) => {
    settingsController_1.settingsController.updatePaymentSetting(req, res);
});
exports.default = router;
//# sourceMappingURL=settingsRoutes.js.map