"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const zonesController_1 = require("../controllers/zonesController");
const router = (0, express_1.Router)();
// GET /api/zones - Lista de zonas geográficas
router.get('/', (req, res) => {
    zonesController_1.zonesController.getZones(req, res);
});
// GET /api/zones/:key/pricing - Precios de la zona especificada
router.get('/:key/pricing', (req, res) => {
    zonesController_1.zonesController.getZonePricing(req, res);
});
exports.default = router;
//# sourceMappingURL=zonesRoutes.js.map