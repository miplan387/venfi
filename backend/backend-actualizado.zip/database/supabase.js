"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supabase = exports.isSupabaseConfigured = void 0;
const supabase_js_1 = require("@supabase/supabase-js");
require("../config/env");
const supabaseUrl = (process.env.SUPABASE_URL || '').trim();
const supabaseServiceRoleKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
const isPlaceholderConfig = !supabaseUrl ||
    !supabaseServiceRoleKey ||
    supabaseUrl.includes('your-project') ||
    supabaseServiceRoleKey.includes('your-') ||
    supabaseServiceRoleKey.includes('TU_');
exports.isSupabaseConfigured = !isPlaceholderConfig;
/**
 * Cliente oficial de Supabase (API REST sobre HTTPS / Puerto 443).
 * Utiliza SUPABASE_SERVICE_ROLE_KEY en backend para omitir RLS de forma segura.
 * Es null cuando las variables no están definidas o son placeholders locales.
 */
exports.supabase = exports.isSupabaseConfigured
    ? (0, supabase_js_1.createClient)(supabaseUrl, supabaseServiceRoleKey, {
        auth: {
            autoRefreshToken: false,
            persistSession: false
        }
    })
    : null;
if (exports.isSupabaseConfigured) {
    console.log('✅ Cliente Supabase REST (HTTPS) inicializado correctamente');
}
else {
    console.log('ℹ️ SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY no configuradas para producción; usando conexión local');
}
//# sourceMappingURL=supabase.js.map