"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pool = exports.db = void 0;
const pg_1 = require("pg");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const env_1 = require("../config/env");
class DatabaseManager {
    pool = null;
    isConnectedToPostgres = false;
    // Almacén en memoria de respaldo para desarrollo local ágil / fallback
    inMemoryDb = {
        users: [],
        payments: [],
        ranking: [],
        clicks_log: [],
        notifications: [],
        rates_history: [],
        zelle_payments: [],
        commodity_history: [],
        zones: [],
        zone_pricing: [],
        visits: [
            { id: 1, total_visits: 0, active_users: 1, last_updated: new Date().toISOString() }
        ],
        payment_settings: [
            { key: 'pago_movil', value: { bank: 'BNC', phone: '0412-4160819', idNumber: 'V-11112387', beneficiary: 'Venfidata C.A.' }, updated_at: new Date().toISOString() },
            { key: 'zinli', value: { email: 'miplan3d@gmail.com', name: 'Venfidata' }, updated_at: new Date().toISOString() },
            { key: 'binance', value: { email: 'pagos@venfidata.com', merchantId: '284910482' }, updated_at: new Date().toISOString() },
            { key: 'crypto', value: { wallet: 'TU_DIRECCION_WALLET_AQUI', network: 'USDT (TRC20)' }, updated_at: new Date().toISOString() }
        ],
        payment_methods: [
            { id: 1, key: 'binance', name: 'Binance Pay (USDT)', icon: '🟡', description: 'Pago instantáneo con criptomonedas y confirmación automática por Webhook.', fields: { merchantId: '284910482', currency: 'USDT' }, is_active: true, requires_approval: false, sort_order: 1 },
            { id: 2, key: 'zinli', name: 'Zinli (USD)', icon: '💳', description: 'Pago con Zinli, billetera digital en dólares con acreditación inmediata.', fields: { email: 'miplan3d@gmail.com', name: 'Venfidata Publicidad' }, is_active: true, requires_approval: true, sort_order: 2 },
            { id: 3, key: 'pago_movil', name: 'Pago Móvil (VES)', icon: '📱', description: 'Pago interbancario en Bolívares con QR dinámico a tasa oficial BCV.', fields: { bank: 'BNC (Banco Nacional de Crédito)', bankCode: '0191', phone: '0412-4160819', idNumber: 'V-11112387', beneficiary: 'Venfidata Publicidad & Medios C.A.' }, is_active: true, requires_approval: true, sort_order: 3 }
        ],
        remittance_providers: [
            {
                id: 1,
                key: 'binance_p2p',
                name: 'Binance P2P (USDT / PagoMóvil)',
                icon: '🟡',
                description: 'Comercio P2P directo sin comisiones intermedias a tasa USDT de mercado',
                countries: ['USA', 'COLOMBIA', 'PERU', 'CHILE', 'BRASIL', 'ARGENTINA', 'ESPANA', 'EUR', 'EUROPA'],
                rate_multiplier: 1.002,
                rate_usd_bs: 0,
                buy_rate_multiplier: 0.9980,
                sell_rate_multiplier: 1.0020,
                buy_rate: 0,
                sell_rate: 0,
                commission_percent: 0.0,
                commission_fixed_usd: 0.0,
                delivery_time: '5 - 15 min (Inmediato)',
                payment_methods: ['Pago local', 'PagoMóvil', 'Transferencia Bs'],
                delivery_methods: ['Pago Móvil', 'Transferencia Bs'],
                rating: 4.9,
                badge: 'MEJOR TASA & CERO COMISIÓN',
                url: 'https://p2p.binance.com/es-LA',
                market_type: 'parallel',
                sort_order: 1,
                is_active: true
            },
            {
                id: 2,
                key: 'airtm',
                name: 'Airtm Remesas',
                icon: '🔵',
                description: 'Billetera digital multimoneda para la diáspora venezolana',
                countries: ['USA', 'COLOMBIA', 'PERU', 'CHILE', 'BRASIL', 'ARGENTINA', 'ESPANA', 'EUR', 'EUROPA'],
                rate_multiplier: 0.985,
                rate_usd_bs: 0,
                buy_rate_multiplier: 0.9650,
                sell_rate_multiplier: 0.9850,
                buy_rate: 0,
                sell_rate: 0,
                commission_percent: 2.8,
                commission_fixed_usd: 0.5,
                delivery_time: '15 - 30 min',
                payment_methods: ['Bancos locales', 'PagoMóvil'],
                delivery_methods: ['Pago Móvil', 'Transferencia Bancaria'],
                rating: 4.6,
                badge: 'MULTIMONEDA DIÁSPORA',
                url: 'https://airtm.com',
                market_type: 'parallel',
                sort_order: 2,
                is_active: true
            },
            {
                id: 3,
                key: 'zoom',
                name: 'Zoom / Western Union Internacional',
                icon: '🔴',
                description: 'Red oficial autorizada de casas de cambio y remesas en Venezuela',
                countries: ['USA', 'COLOMBIA', 'PERU', 'CHILE', 'BRASIL', 'ARGENTINA', 'ESPANA', 'EUR', 'EUROPA'],
                rate_multiplier: 0.95,
                rate_usd_bs: 0,
                buy_rate_multiplier: 0.9300,
                sell_rate_multiplier: 0.9500,
                buy_rate: 0,
                sell_rate: 0,
                commission_percent: 4.5,
                commission_fixed_usd: 1.5,
                delivery_time: '1 - 4 horas',
                payment_methods: ['Agencias Zoom', 'PagoMóvil', 'Retiro Efectivo'],
                delivery_methods: ['Pago Móvil', 'Transferencia Bs', 'Retiro Efectivo'],
                rating: 4.7,
                badge: 'RED OFICIAL AUTORIZADA',
                url: 'https://zoom.red/remesas',
                market_type: 'parallel',
                sort_order: 3,
                is_active: true
            },
            {
                id: 4,
                key: 'moneygram',
                name: 'MoneyGram Diáspora',
                icon: '🌐',
                description: 'Red de transferencias y depósitos bancarios directos internacionales',
                countries: ['USA', 'COLOMBIA', 'PERU', 'CHILE', 'BRASIL', 'ARGENTINA', 'ESPANA', 'EUR', 'EUROPA'],
                rate_multiplier: 0.94,
                rate_usd_bs: 0,
                buy_rate_multiplier: 0.9200,
                sell_rate_multiplier: 0.9400,
                buy_rate: 0,
                sell_rate: 0,
                commission_percent: 5.0,
                commission_fixed_usd: 2.0,
                delivery_time: '24 horas',
                payment_methods: ['Depósito Bancario Directo'],
                delivery_methods: ['Depósito Bancario Directo'],
                rating: 4.4,
                badge: 'RED BANCARIA GLOBAL',
                url: 'https://moneygram.com',
                market_type: 'parallel',
                sort_order: 4,
                is_active: true
            },
            {
                id: 5,
                key: 'italcambio',
                name: 'ItalCambio',
                icon: '🇮🇹',
                description: 'Envíos desde Italia y Europa a Venezuela',
                countries: ['ITALIA', 'ESPAÑA', 'ESPANA', 'EUROPA', 'EUR', 'USA'],
                rate_multiplier: 0.965,
                rate_usd_bs: 0,
                buy_rate_multiplier: 0.9450,
                sell_rate_multiplier: 0.9650,
                buy_rate: 0,
                sell_rate: 0,
                commission_percent: 3.5,
                commission_fixed_usd: 3.00,
                delivery_time: '24 - 48 horas',
                payment_methods: ['Transferencia EUR', 'Efectivo EUR'],
                delivery_methods: ['Pago Móvil', 'Transferencia Bs', 'Efectivo Bs'],
                rating: 4.5,
                badge: 'ESPECIALISTA EUROPA',
                url: 'https://italcambio.com',
                market_type: 'official',
                sort_order: 5,
                is_active: true
            },
            {
                id: 6,
                key: 'angulo_lopez',
                name: 'Casa de Cambio Angulo López',
                icon: '🏛️',
                description: 'Casa de cambio tradicional venezolana con amplia trayectoria',
                countries: ['COLOMBIA', 'USA', 'ESPAÑA', 'ESPANA', 'EUR', 'PANAMA', 'PERU', 'CHILE'],
                rate_multiplier: 0.96,
                rate_usd_bs: 0,
                buy_rate_multiplier: 0.9400,
                sell_rate_multiplier: 0.9600,
                buy_rate: 0,
                sell_rate: 0,
                commission_percent: 3.8,
                commission_fixed_usd: 2.50,
                delivery_time: '12 - 24 horas',
                payment_methods: ['Transferencia Bancaria', 'Depósito en Efectivo', 'Zelle'],
                delivery_methods: ['Pago Móvil', 'Transferencia Bs', 'Efectivo Bs'],
                rating: 4.6,
                badge: 'TRADICIÓN & SEGURIDAD',
                url: 'https://casadecambioangulolopez.com',
                market_type: 'official',
                sort_order: 6,
                is_active: true
            },
            {
                id: 7,
                key: 'insular',
                name: 'Insular Tasa de Cambio',
                icon: '🏝️',
                description: 'Casa de cambio con presencia en la región insular y oriente del país',
                countries: ['USA', 'COLOMBIA', 'BRASIL', 'ESPAÑA', 'ESPANA', 'EUR', 'CHILE', 'PERU', 'PANAMA'],
                rate_multiplier: 0.955,
                rate_usd_bs: 0,
                buy_rate_multiplier: 0.9350,
                sell_rate_multiplier: 0.9550,
                buy_rate: 0,
                sell_rate: 0,
                commission_percent: 4.0,
                commission_fixed_usd: 2.00,
                delivery_time: '24 horas',
                payment_methods: ['Transferencia Internacional', 'Efectivo USD/EUR'],
                delivery_methods: ['Pago Móvil', 'Transferencia Bs', 'Retiro Agencias'],
                rating: 4.4,
                badge: 'REGIÓN INSULAR & ORIENTE',
                url: 'https://insularcambio.com',
                market_type: 'official',
                sort_order: 7,
                is_active: true
            }
        ]
    };
    constructor() {
        if (env_1.config.databaseUrl) {
            this.pool = new pg_1.Pool({
                connectionString: env_1.config.databaseUrl,
                ssl: env_1.config.nodeEnv === 'production' ? { rejectUnauthorized: false } : false,
                max: 30, // Pool robusto para concurrencia
                idleTimeoutMillis: 30000,
                connectionTimeoutMillis: 10000
            });
        }
    }
    async init() {
        try {
            if (this.pool) {
                const client = await this.pool.connect();
                this.isConnectedToPostgres = true;
                console.log('✅ Conectado exitosamente a PostgreSQL (Supabase / Pool)');
                // Ejecutar schema si es necesario
                let schemaPath = path_1.default.join(__dirname, 'schema.sql');
                if (!fs_1.default.existsSync(schemaPath)) {
                    const srcSchemaPath = path_1.default.join(__dirname, '../../src/database/schema.sql');
                    if (fs_1.default.existsSync(srcSchemaPath)) {
                        schemaPath = srcSchemaPath;
                    }
                }
                if (fs_1.default.existsSync(schemaPath)) {
                    const schemaSql = fs_1.default.readFileSync(schemaPath, 'utf-8');
                    await client.query(schemaSql);
                }
                // Asegurar que la tabla visits existe con su registro inicial (id=1)
                await client.query(`
          CREATE TABLE IF NOT EXISTS visits (
            id SERIAL PRIMARY KEY,
            total_visits BIGINT DEFAULT 0,
            active_users INT DEFAULT 0,
            last_updated TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
          );

          INSERT INTO visits (id, total_visits, active_users, last_updated)
          VALUES (1, 0, 0, CURRENT_TIMESTAMP)
          ON CONFLICT (id) DO NOTHING;
        `);
                // Asegurar columnas de variación en rates_history
                await client.query(`
          ALTER TABLE rates_history ADD COLUMN IF NOT EXISTS variation_abs DECIMAL(10,4);
          ALTER TABLE rates_history ADD COLUMN IF NOT EXISTS variation_pct DECIMAL(5,2);
          ALTER TABLE rates_history ADD COLUMN IF NOT EXISTS direction VARCHAR(10);
        `);
                // Asegurar columnas de buy_rate, sell_rate y market_type en remittance_providers
                await client.query(`
          ALTER TABLE remittance_providers ADD COLUMN IF NOT EXISTS buy_rate_multiplier DECIMAL(5,4) DEFAULT 0.9750;
          ALTER TABLE remittance_providers ADD COLUMN IF NOT EXISTS sell_rate_multiplier DECIMAL(5,4) DEFAULT 1.0000;
          ALTER TABLE remittance_providers ADD COLUMN IF NOT EXISTS buy_rate DECIMAL(10,4) DEFAULT 0;
          ALTER TABLE remittance_providers ADD COLUMN IF NOT EXISTS sell_rate DECIMAL(10,4) DEFAULT 0;
          ALTER TABLE remittance_providers ADD COLUMN IF NOT EXISTS market_type VARCHAR(20) DEFAULT 'parallel';
        `);
                // Migración de clasificación de mercado
                await client.query(`
          UPDATE remittance_providers SET market_type = 'official' WHERE key IN ('italcambio', 'angulo_lopez', 'insular');
          UPDATE remittance_providers SET market_type = 'parallel' WHERE key IN ('binance_p2p', 'airtm', 'zinli', 'wally', 'zoom', 'moneygram');
        `);
                // Migración e inicialización de Zonas y Tarifas
                await client.query(`
          CREATE TABLE IF NOT EXISTS zones (
            id SERIAL PRIMARY KEY,
            key VARCHAR(50) UNIQUE NOT NULL,
            name VARCHAR(100) NOT NULL,
            type VARCHAR(20) NOT NULL,
            icon VARCHAR(10) DEFAULT '📍',
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
          );

          INSERT INTO zones (key, name, type, icon, sort_order) VALUES
          ('nacional', 'Nacional', 'national', '🇻🇪', 1),
          ('caracas', 'Caracas', 'city', '🏙️', 2),
          ('maracaibo', 'Maracaibo', 'city', '🌉', 3),
          ('valencia', 'Valencia', 'city', '🌆', 4)
          ON CONFLICT (key) DO NOTHING;

          CREATE TABLE IF NOT EXISTS zone_pricing (
            id SERIAL PRIMARY KEY,
            zone_key VARCHAR(50) NOT NULL REFERENCES zones(key),
            position INT NOT NULL CHECK (position BETWEEN 1 AND 10),
            tier VARCHAR(20) NOT NULL,
            price_usd DECIMAL(10,2) NOT NULL,
            duration_hours INT DEFAULT 24,
            is_active BOOLEAN DEFAULT TRUE,
            UNIQUE(zone_key, position)
          );

          INSERT INTO zone_pricing (zone_key, position, tier, price_usd) VALUES
          ('nacional', 1, 'gold', 15.00), ('nacional', 2, 'silver', 10.00), ('nacional', 3, 'silver', 10.00), ('nacional', 4, 'bronze', 5.00), ('nacional', 5, 'bronze', 5.00), ('nacional', 6, 'dark', 3.00), ('nacional', 7, 'dark', 3.00), ('nacional', 8, 'dark', 3.00), ('nacional', 9, 'dark', 3.00), ('nacional', 10, 'dark', 3.00),
          ('caracas', 1, 'gold', 10.00), ('caracas', 2, 'silver', 6.00), ('caracas', 3, 'bronze', 4.00),
          ('maracaibo', 1, 'gold', 10.00), ('maracaibo', 2, 'silver', 6.00), ('maracaibo', 3, 'bronze', 4.00),
          ('valencia', 1, 'gold', 10.00), ('valencia', 2, 'silver', 6.00), ('valencia', 3, 'bronze', 4.00)
          ON CONFLICT (zone_key, position) DO NOTHING;

          ALTER TABLE ranking ADD COLUMN IF NOT EXISTS zone_key VARCHAR(50) DEFAULT 'nacional';
          CREATE INDEX IF NOT EXISTS idx_ranking_zone ON ranking(zone_key, position);
          UPDATE ranking SET zone_key = 'nacional' WHERE zone_key IS NULL;
          ALTER TABLE ranking DROP CONSTRAINT IF EXISTS ranking_position_key;
          ALTER TABLE ranking DROP CONSTRAINT IF EXISTS ranking_tier_check;
          DO $$
          BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ranking_zone_position_key') THEN
              ALTER TABLE ranking ADD CONSTRAINT ranking_zone_position_key UNIQUE (zone_key, position);
            END IF;
            IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ranking_tier_check') THEN
              ALTER TABLE ranking ADD CONSTRAINT ranking_tier_check CHECK (tier IN ('gold', 'silver', 'bronze', 'dark'));
            END IF;
          END $$;

          ALTER TABLE payments ADD COLUMN IF NOT EXISTS zone_key VARCHAR(50) DEFAULT 'nacional';
          CREATE INDEX IF NOT EXISTS idx_payments_zone ON payments(zone_key);
          UPDATE payments SET zone_key = 'nacional' WHERE zone_key IS NULL;

          -- Tabla de configuración dinámica de pagos
          CREATE TABLE IF NOT EXISTS payment_settings (
            key VARCHAR(50) PRIMARY KEY,
            value JSONB NOT NULL,
            updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
          );

          INSERT INTO payment_settings (key, value) VALUES
          ('pago_movil', '{"bank": "BNC", "phone": "0412-4160819", "idNumber": "V-11112387", "beneficiary": "Venfidata C.A."}'::jsonb),
          ('zinli', '{"email": "miplan3d@gmail.com", "name": "Venfidata"}'::jsonb),
          ('binance', '{"email": "pagos@venfidata.com", "merchantId": "284910482"}'::jsonb),
          ('crypto', '{"wallet": "TU_DIRECCION_WALLET_AQUI", "network": "USDT (TRC20)"}'::jsonb)
          ON CONFLICT (key) DO NOTHING;
        `);
                // Ejecutar seed inicial si ranking está vacío
                const rankingCountRes = await client.query('SELECT COUNT(*) FROM ranking');
                if (parseInt(rankingCountRes.rows[0].count, 10) === 0) {
                    const seedPath = path_1.default.join(__dirname, 'seed.sql');
                    if (fs_1.default.existsSync(seedPath)) {
                        const seedSql = fs_1.default.readFileSync(seedPath, 'utf-8');
                        await client.query(seedSql);
                    }
                }
                // Asegurar que las casas de cambio iniciales existan en remittance_providers
                for (const p of this.inMemoryDb.remittance_providers) {
                    await client.query(`INSERT INTO remittance_providers (
              key, name, icon, description, countries, rate_multiplier, rate_usd_bs,
              buy_rate_multiplier, sell_rate_multiplier, buy_rate, sell_rate,
              commission_percent, commission_fixed_usd, delivery_time, payment_methods,
              delivery_methods, rating, badge, url, market_type, sort_order, is_active
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22)
            ON CONFLICT (key) DO NOTHING`, [
                        p.key, p.name, p.icon, p.description, JSON.stringify(p.countries || []),
                        p.rate_multiplier || 1.0, p.rate_usd_bs || 0,
                        p.buy_rate_multiplier || 0.9750, p.sell_rate_multiplier || 1.0000,
                        p.buy_rate || 0, p.sell_rate || 0,
                        p.commission_percent || 0, p.commission_fixed_usd || 0, p.delivery_time || '24 horas',
                        JSON.stringify(p.payment_methods || []), JSON.stringify(p.delivery_methods || []),
                        p.rating || 4.5, p.badge || '', p.url || '', p.market_type || 'parallel', p.sort_order || 0, p.is_active ?? true
                    ]);
                }
                client.release();
            }
        }
        catch (err) {
            console.warn('⚠️ No se pudo conectar a PostgreSQL externo. Iniciando Motor de Base de Datos En-Memoria Relacional para desarrollo:', err.message);
            this.isConnectedToPostgres = false;
            this.seedInMemory();
        }
    }
    seedInMemory() {
        // Cargar usuarios por defecto
        this.inMemoryDb.users = [
            {
                id: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
                email: 'soporte@venfidata.com',
                username: 'venfi_admin',
                password_hash: '$2a$10$QjY8p1Q3z5S.E7xN0kP8yO2sK7wJ7G8h0d6.l7v1k1X.r9i4l4t.y',
                role: 'admin',
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString(),
                wallet_address: null,
                google_id: null
            },
            {
                id: 'b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
                email: 'electrocaracas@gmail.com',
                username: 'electrocaracas',
                password_hash: '$2a$10$QjY8p1Q3z5S.E7xN0kP8yO2sK7wJ7G8h0d6.l7v1k1X.r9i4l4t.y',
                role: 'advertiser',
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString(),
                wallet_address: '0x71C...4b9F',
                google_id: null
            }
        ];
        // Cargar Ranking Inicial por Defecto
        this.inMemoryDb.ranking = [
            {
                id: 1,
                position: 1,
                user_id: 'b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
                payment_id: null,
                business_name: 'Digibird - Desarrollo de Software',
                target_url: 'https://digibird.com',
                slogan: 'Soluciones tecnológicas a medida',
                category: 'Software & Tecnología',
                avatar: '🦅',
                tier: 'gold',
                amount_paid: 15.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 3420,
                views_received: 48920,
                is_active: true
            },
            {
                id: 2,
                position: 2,
                user_id: null,
                payment_id: null,
                business_name: 'Venfidata - Inteligencia Financiera y publicidad',
                target_url: 'https://venfidata.com',
                slogan: 'Tu centro de información financiera',
                category: 'Finanzas & Publicidad',
                avatar: '📊',
                tier: 'silver',
                amount_paid: 10.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 1890,
                views_received: 29400,
                is_active: true
            },
            {
                id: 3,
                position: 3,
                user_id: null,
                payment_id: null,
                business_name: 'DigiHIS - Sistema Administrativo de Clínicas',
                target_url: 'https://digihis.com',
                slogan: 'Gestión médica inteligente',
                category: 'Salud & Software',
                avatar: '🏥',
                tier: 'bronze',
                amount_paid: 10.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 1450,
                views_received: 24100,
                is_active: true
            },
            {
                id: 4,
                position: 4,
                user_id: null,
                payment_id: null,
                business_name: 'MG Empresarial',
                target_url: 'https://mgempresarial.com',
                slogan: 'Soluciones corporativas',
                category: 'Corporativo & Negocios',
                avatar: '🏢',
                tier: 'dark',
                amount_paid: 5.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 890,
                views_received: 14200,
                is_active: true
            },
            {
                id: 5,
                position: 5,
                user_id: null,
                payment_id: null,
                business_name: 'MG Empresarial',
                target_url: 'https://mgempresarial.com',
                slogan: 'Soluciones corporativas',
                category: 'Corporativo & Negocios',
                avatar: '🏢',
                tier: 'dark',
                amount_paid: 5.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 760,
                views_received: 11800,
                is_active: true
            },
            {
                id: 6,
                position: 6,
                user_id: null,
                payment_id: null,
                business_name: 'MG Empresarial',
                target_url: 'https://mgempresarial.com',
                slogan: 'Soluciones corporativas',
                category: 'Corporativo & Negocios',
                avatar: '🏢',
                tier: 'dark',
                amount_paid: 5.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 640,
                views_received: 9500,
                is_active: true
            },
            {
                id: 7,
                position: 7,
                user_id: null,
                payment_id: null,
                business_name: 'MG Empresarial',
                target_url: 'https://mgempresarial.com',
                slogan: 'Soluciones corporativas',
                category: 'Corporativo & Negocios',
                avatar: '🏢',
                tier: 'dark',
                amount_paid: 5.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 580,
                views_received: 8900,
                is_active: true
            },
            {
                id: 8,
                position: 8,
                user_id: null,
                payment_id: null,
                business_name: 'MG Empresarial',
                target_url: 'https://mgempresarial.com',
                slogan: 'Soluciones corporativas',
                category: 'Corporativo & Negocios',
                avatar: '🏢',
                tier: 'dark',
                amount_paid: 5.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 490,
                views_received: 7200,
                is_active: true
            },
            {
                id: 9,
                position: 9,
                user_id: null,
                payment_id: null,
                business_name: 'MG Empresarial',
                target_url: 'https://mgempresarial.com',
                slogan: 'Soluciones corporativas',
                category: 'Corporativo & Negocios',
                avatar: '🏢',
                tier: 'dark',
                amount_paid: 5.00,
                start_time: new Date().toISOString(),
                end_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
                clicks_received: 410,
                views_received: 6100,
                is_active: true
            },
            {
                id: 10,
                position: 10,
                user_id: null,
                payment_id: null,
                business_name: 'MG Empresarial',
                target_url: 'https://mgempresarial.com',
                slogan: 'Soluciones corporativas',
                category: 'Corporativo & Negocios',
                avatar: '🏢',
                tier: 'dark',
                amount_paid: 5.00,
                start_time: new Date().toISOString(),
                end_time: null,
                clicks_received: 120,
                views_received: 4500,
                is_active: true
            }
        ];
        // Asignar zone_key nacional a los rankings por defecto
        this.inMemoryDb.ranking.forEach(r => {
            r.zone_key = 'nacional';
        });
        // Zonas iniciales
        this.inMemoryDb.zones = [
            { id: 1, key: 'nacional', name: 'Nacional', type: 'national', icon: '🇻🇪', is_active: true, sort_order: 1 },
            { id: 2, key: 'caracas', name: 'Caracas', type: 'city', icon: '🏙️', is_active: true, sort_order: 2 },
            { id: 3, key: 'maracaibo', name: 'Maracaibo', type: 'city', icon: '🌉', is_active: true, sort_order: 3 },
            { id: 4, key: 'valencia', name: 'Valencia', type: 'city', icon: '🌆', is_active: true, sort_order: 4 }
        ];
        // Tarifas iniciales por zona
        this.inMemoryDb.zone_pricing = [
            { id: 1, zone_key: 'nacional', position: 1, tier: 'gold', price_usd: 15.00, duration_hours: 24, is_active: true },
            { id: 2, zone_key: 'nacional', position: 2, tier: 'silver', price_usd: 10.00, duration_hours: 24, is_active: true },
            { id: 3, zone_key: 'nacional', position: 3, tier: 'silver', price_usd: 10.00, duration_hours: 24, is_active: true },
            { id: 4, zone_key: 'nacional', position: 4, tier: 'bronze', price_usd: 5.00, duration_hours: 24, is_active: true },
            { id: 5, zone_key: 'nacional', position: 5, tier: 'bronze', price_usd: 5.00, duration_hours: 24, is_active: true },
            { id: 6, zone_key: 'nacional', position: 6, tier: 'dark', price_usd: 3.00, duration_hours: 24, is_active: true },
            { id: 7, zone_key: 'nacional', position: 7, tier: 'dark', price_usd: 3.00, duration_hours: 24, is_active: true },
            { id: 8, zone_key: 'nacional', position: 8, tier: 'dark', price_usd: 3.00, duration_hours: 24, is_active: true },
            { id: 9, zone_key: 'nacional', position: 9, tier: 'dark', price_usd: 3.00, duration_hours: 24, is_active: true },
            { id: 10, zone_key: 'nacional', position: 10, tier: 'dark', price_usd: 3.00, duration_hours: 24, is_active: true },
            { id: 11, zone_key: 'caracas', position: 1, tier: 'gold', price_usd: 10.00, duration_hours: 24, is_active: true },
            { id: 12, zone_key: 'caracas', position: 2, tier: 'silver', price_usd: 6.00, duration_hours: 24, is_active: true },
            { id: 13, zone_key: 'caracas', position: 3, tier: 'bronze', price_usd: 4.00, duration_hours: 24, is_active: true },
            { id: 14, zone_key: 'maracaibo', position: 1, tier: 'gold', price_usd: 10.00, duration_hours: 24, is_active: true },
            { id: 15, zone_key: 'maracaibo', position: 2, tier: 'silver', price_usd: 6.00, duration_hours: 24, is_active: true },
            { id: 16, zone_key: 'maracaibo', position: 3, tier: 'bronze', price_usd: 4.00, duration_hours: 24, is_active: true },
            { id: 17, zone_key: 'valencia', position: 1, tier: 'gold', price_usd: 10.00, duration_hours: 24, is_active: true },
            { id: 18, zone_key: 'valencia', position: 2, tier: 'silver', price_usd: 6.00, duration_hours: 24, is_active: true },
            { id: 19, zone_key: 'valencia', position: 3, tier: 'bronze', price_usd: 4.00, duration_hours: 24, is_active: true }
        ];
        // Ajustes iniciales de recepción de pagos
        this.inMemoryDb.payment_settings = [
            { key: 'pago_movil', value: { bank: 'BNC', phone: '0412-4160819', idNumber: 'V-11112387', beneficiary: 'Venfidata C.A.' }, updated_at: new Date().toISOString() },
            { key: 'zinli', value: { email: 'miplan3d@gmail.com', name: 'Venfidata' }, updated_at: new Date().toISOString() },
            { key: 'binance', value: { email: 'pagos@venfidata.com', merchantId: '284910482' }, updated_at: new Date().toISOString() },
            { key: 'crypto', value: { wallet: 'TU_DIRECCION_WALLET_AQUI', network: 'USDT (TRC20)' }, updated_at: new Date().toISOString() }
        ];
    }
    // Getters para acceso a la base de datos
    getInMemoryStore() {
        return this.inMemoryDb;
    }
    get isPostgresActive() {
        return this.isConnectedToPostgres;
    }
    async query(text, params) {
        if (this.isConnectedToPostgres && this.pool) {
            const res = await this.pool.query(text, params);
            return {
                rows: res.rows,
                rowCount: res.rowCount || 0
            };
        }
        // Si está en modo memoria, los servicios usan directamente los repositorios
        return { rows: [], rowCount: 0 };
    }
}
exports.db = new DatabaseManager();
exports.pool = exports.db;
//# sourceMappingURL=db.js.map