"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zonesController = exports.ZonesController = void 0;
const zonesService_1 = require("../services/zonesService");
class ZonesController {
    /**
     * GET /api/zones
     * Obtiene la lista de zonas geográficas disponibles (Nacional, Caracas, Maracaibo, etc.)
     */
    async getZones(req, res) {
        try {
            const zones = await zonesService_1.zonesService.getAllZones();
            res.status(200).json({
                success: true,
                count: zones.length,
                data: zones
            });
        }
        catch (err) {
            console.error('[ZonesController Error]:', err);
            res.status(500).json({
                success: false,
                message: err.message || 'Error al obtener la lista de zonas'
            });
        }
    }
    /**
     * GET /api/zones/:key/pricing
     * Obtiene la estructura de precios y tiers para una zona específica
     */
    async getZonePricing(req, res) {
        try {
            const key = req.params.key || 'nacional';
            const pricing = await zonesService_1.zonesService.getZonePricing(key);
            res.status(200).json({
                success: true,
                zone: key,
                count: pricing.length,
                data: pricing
            });
        }
        catch (err) {
            console.error('[ZonesController Error]:', err);
            res.status(500).json({
                success: false,
                message: err.message || 'Error al obtener los precios de la zona'
            });
        }
    }
    /**
     * GET /api/admin/pricing
     * Obtiene todos los registros de zone_pricing para el Centro de Control
     */
    async getAllPricing(req, res) {
        try {
            const pricing = await zonesService_1.zonesService.getAllPricing();
            res.status(200).json({
                success: true,
                count: pricing.length,
                data: pricing
            });
        }
        catch (err) {
            console.error('[ZonesController Error]:', err);
            res.status(500).json({
                success: false,
                message: err.message || 'Error al obtener la configuración de precios'
            });
        }
    }
    /**
     * PUT /api/admin/pricing/:id
     * Actualiza precio, duración y estado de un puesto en zone_pricing
     */
    async updatePricing(req, res) {
        try {
            const id = req.params.id;
            const { zone_key, position, tier, price_usd, duration_hours, is_active } = req.body || {};
            const updated = await zonesService_1.zonesService.updatePricing(id, {
                zone_key,
                position,
                tier,
                price_usd,
                duration_hours,
                is_active
            });
            res.status(200).json({
                success: true,
                message: 'Tarifa y duración actualizadas exitosamente',
                data: updated
            });
        }
        catch (err) {
            console.error('[ZonesController Update Error]:', err);
            res.status(400).json({
                success: false,
                message: err.message || 'Error al actualizar la tarifa'
            });
        }
    }
    /**
     * POST /api/admin/pricing
     * Crea una nueva tarifa en zone_pricing
     */
    async createPricing(req, res) {
        try {
            const { zone_key, position, tier, price_usd, duration_hours, is_active } = req.body || {};
            const created = await zonesService_1.zonesService.createPricing({
                zone_key,
                position,
                tier,
                price_usd,
                duration_hours,
                is_active
            });
            res.status(201).json({
                success: true,
                message: 'Nueva tarifa creada exitosamente',
                data: created
            });
        }
        catch (err) {
            console.error('[ZonesController Create Error]:', err);
            res.status(400).json({
                success: false,
                message: err.message || 'Error al crear la tarifa'
            });
        }
    }
    /**
     * DELETE /api/admin/pricing/:id
     * Elimina una tarifa de zone_pricing
     */
    async deletePricing(req, res) {
        try {
            const id = req.params.id;
            const result = await zonesService_1.zonesService.deletePricing(id);
            res.status(200).json({
                success: true,
                message: result.message,
                data: result
            });
        }
        catch (err) {
            console.error('[ZonesController Delete Error]:', err);
            res.status(400).json({
                success: false,
                message: err.message || 'Error al eliminar la tarifa'
            });
        }
    }
}
exports.ZonesController = ZonesController;
exports.zonesController = new ZonesController();
//# sourceMappingURL=zonesController.js.map