"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsController = exports.SettingsController = void 0;
const settingsService_1 = require("../services/settingsService");
class SettingsController {
    /**
     * GET /api/settings/payments (Público)
     * Devuelve la configuración actual de todos los métodos de pago
     */
    async getPaymentSettings(req, res) {
        try {
            const settings = await settingsService_1.settingsService.getPaymentSettings();
            res.status(200).json({
                success: true,
                data: settings
            });
        }
        catch (err) {
            res.status(500).json({
                success: false,
                message: err.message || 'Error al obtener la configuración de pagos'
            });
        }
    }
    /**
     * PUT /api/settings/payments/:key (Protegido Admin)
     * Actualiza la configuración de un método de pago
     */
    async updatePaymentSetting(req, res) {
        try {
            const key = req.params.key?.toLowerCase();
            if (!key) {
                res.status(400).json({
                    success: false,
                    message: 'El parámetro key del método de pago es obligatorio'
                });
                return;
            }
            const body = req.body;
            if (!body || typeof body !== 'object') {
                res.status(400).json({
                    success: false,
                    message: 'El cuerpo de la solicitud debe ser un objeto JSON válido'
                });
                return;
            }
            const updated = await settingsService_1.settingsService.updatePaymentSetting(key, body);
            res.status(200).json({
                success: true,
                message: `Configuración de '${key}' actualizada exitosamente`,
                data: updated
            });
        }
        catch (err) {
            res.status(500).json({
                success: false,
                message: err.message || 'Error al actualizar la configuración de pago'
            });
        }
    }
}
exports.SettingsController = SettingsController;
exports.settingsController = new SettingsController();
//# sourceMappingURL=settingsController.js.map