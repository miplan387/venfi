"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsService = void 0;
const db_1 = require("../database/db");
const supabase_1 = require("../database/supabase");
const paymentService_1 = require("./paymentService");
class SettingsService {
    /**
     * Obtiene todos los ajustes de configuración de pagos
     */
    async getPaymentSettings() {
        if (supabase_1.supabase) {
            const { data, error } = await supabase_1.supabase
                .from('payment_settings')
                .select('key, value, updated_at')
                .order('key', { ascending: true });
            if (error)
                throw new Error(error.message);
            const settingsMap = {};
            for (const row of data || []) {
                settingsMap[row.key] = {
                    ...row.value,
                    updated_at: row.updated_at
                };
            }
            return settingsMap;
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT key, value, updated_at FROM payment_settings ORDER BY key ASC');
            const settingsMap = {};
            for (const row of res.rows) {
                settingsMap[row.key] = {
                    ...row.value,
                    updated_at: row.updated_at
                };
            }
            return settingsMap;
        }
        const store = db_1.db.getInMemoryStore();
        const settingsMap = {};
        for (const item of store.payment_settings || []) {
            settingsMap[item.key] = {
                ...item.value,
                updated_at: item.updated_at
            };
        }
        return settingsMap;
    }
    /**
     * Obtiene la configuración de un método de pago por su key
     */
    async getPaymentSettingByKey(key) {
        if (supabase_1.supabase) {
            const { data, error } = await supabase_1.supabase
                .from('payment_settings')
                .select('key, value, updated_at')
                .eq('key', key)
                .maybeSingle();
            if (error)
                throw new Error(error.message);
            if (!data)
                return null;
            return {
                ...data.value,
                updated_at: data.updated_at
            };
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT key, value, updated_at FROM payment_settings WHERE key = $1', [key]);
            if (res.rows.length === 0)
                return null;
            return {
                ...res.rows[0].value,
                updated_at: res.rows[0].updated_at
            };
        }
        const store = db_1.db.getInMemoryStore();
        const found = (store.payment_settings || []).find((s) => s.key === key);
        if (!found)
            return null;
        return {
            ...found.value,
            updated_at: found.updated_at
        };
    }
    /**
     * Actualiza o crea la configuración de un método de pago
     */
    async updatePaymentSetting(key, value) {
        // Si viene anidado en value, desempaquetar
        const cleanValue = value.value !== undefined ? value.value : value;
        if (supabase_1.supabase) {
            const { data: updated, error } = await supabase_1.supabase
                .from('payment_settings')
                .upsert({
                key,
                value: cleanValue,
                updated_at: new Date().toISOString()
            }, { onConflict: 'key' })
                .select()
                .single();
            if (error)
                throw new Error(error.message);
            if (key === 'pago_movil') {
                paymentService_1.paymentService.updatePagoMovilBankData({
                    bank: cleanValue.bank,
                    phone: cleanValue.phone,
                    idNumber: cleanValue.idNumber,
                    beneficiaryName: cleanValue.beneficiary || cleanValue.beneficiaryName
                });
            }
            return {
                key: updated.key,
                value: updated.value,
                updated_at: updated.updated_at
            };
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query(`INSERT INTO payment_settings (key, value, updated_at)
         VALUES ($1, $2, CURRENT_TIMESTAMP)
         ON CONFLICT (key) DO UPDATE
         SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP
         RETURNING *`, [key, JSON.stringify(cleanValue)]);
            const updated = res.rows[0];
            // Si se actualiza pago_movil, sincronizar con paymentService
            if (key === 'pago_movil') {
                paymentService_1.paymentService.updatePagoMovilBankData({
                    bank: cleanValue.bank,
                    phone: cleanValue.phone,
                    idNumber: cleanValue.idNumber,
                    beneficiaryName: cleanValue.beneficiary || cleanValue.beneficiaryName
                });
            }
            return {
                key: updated.key,
                value: updated.value,
                updated_at: updated.updated_at
            };
        }
        const store = db_1.db.getInMemoryStore();
        if (!store.payment_settings) {
            store.payment_settings = [];
        }
        const idx = store.payment_settings.findIndex((s) => s.key === key);
        const updatedRecord = {
            key,
            value: cleanValue,
            updated_at: new Date().toISOString()
        };
        if (idx >= 0) {
            store.payment_settings[idx] = updatedRecord;
        }
        else {
            store.payment_settings.push(updatedRecord);
        }
        if (key === 'pago_movil') {
            paymentService_1.paymentService.updatePagoMovilBankData({
                bank: cleanValue.bank,
                phone: cleanValue.phone,
                idNumber: cleanValue.idNumber,
                beneficiaryName: cleanValue.beneficiary || cleanValue.beneficiaryName
            });
        }
        return updatedRecord;
    }
}
exports.settingsService = new SettingsService();
//# sourceMappingURL=settingsService.js.map