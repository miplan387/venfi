"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deletePricing = exports.createPricing = exports.updatePricing = exports.getAllPricing = exports.getPriceForPosition = exports.getZonePricing = exports.getAllZones = exports.zonesService = exports.ZonesService = void 0;
const db_1 = require("../database/db");
const supabase_1 = require("../database/supabase");
class ZonesService {
    /**
     * Obtiene todas las zonas geográficas activas ordenadas
     */
    async getAllZones() {
        if (supabase_1.supabase) {
            const { data, error } = await supabase_1.supabase
                .from('zones')
                .select('*')
                .eq('is_active', true)
                .order('sort_order', { ascending: true })
                .order('id', { ascending: true });
            if (error)
                throw new Error(error.message);
            return (data || []).map(this.formatZone);
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM zones WHERE is_active = TRUE ORDER BY sort_order ASC, id ASC');
            return res.rows.map(this.formatZone);
        }
        const store = db_1.db.getInMemoryStore();
        return (store.zones || [])
            .filter((z) => z.is_active !== false)
            .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0))
            .map(this.formatZone);
    }
    /**
     * Obtiene la estructura de precios para una zona específica
     */
    async getZonePricing(zoneKey) {
        const normalizedKey = (zoneKey || 'nacional').toLowerCase().trim();
        if (supabase_1.supabase) {
            const { data, error } = await supabase_1.supabase
                .from('zone_pricing')
                .select('*')
                .eq('zone_key', normalizedKey)
                .eq('is_active', true)
                .order('position', { ascending: true });
            if (error)
                throw new Error(error.message);
            if (data && data.length > 0) {
                return data.map(this.formatPricing);
            }
        }
        else if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM zone_pricing WHERE zone_key = $1 AND is_active = TRUE ORDER BY position ASC', [normalizedKey]);
            if (res.rows.length > 0) {
                return res.rows.map(this.formatPricing);
            }
        }
        else {
            const store = db_1.db.getInMemoryStore();
            const pricings = (store.zone_pricing || [])
                .filter((p) => p.zone_key === normalizedKey && p.is_active !== false)
                .sort((a, b) => a.position - b.position);
            if (pricings.length > 0) {
                return pricings.map(this.formatPricing);
            }
        }
        // Fallback a zona nacional si no existe configuración específica
        if (normalizedKey !== 'nacional') {
            return this.getZonePricing('nacional');
        }
        return [];
    }
    /**
     * Obtiene el precio en USD para una posición dentro de una zona
     */
    async getPriceForPosition(zoneKey, position) {
        const info = await this.getPricingForPosition(zoneKey, position);
        return info.price_usd;
    }
    /**
     * Obtiene el precio y duración configurados para una posición dentro de una zona
     */
    async getPricingForPosition(zoneKey, position) {
        const pos = Math.min(Math.max(1, position), 10);
        const pricings = await this.getZonePricing(zoneKey);
        const item = pricings.find(p => p.position === pos);
        if (item) {
            return {
                price_usd: Number(item.price_usd),
                duration_hours: Number(item.duration_hours || 24)
            };
        }
        // Fallback estandarizado si la posición específica no está definida en la zona
        if (pos === 1)
            return { price_usd: 10.00, duration_hours: 24 };
        if (pos === 2 || pos === 3)
            return { price_usd: 6.00, duration_hours: 24 };
        return { price_usd: 4.00, duration_hours: 24 };
    }
    /**
     * Obtiene TODOS los registros de zone_pricing (para el Centro de Control Admin)
     */
    async getAllPricing() {
        if (supabase_1.supabase) {
            const { data, error } = await supabase_1.supabase
                .from('zone_pricing')
                .select('*')
                .order('zone_key', { ascending: true })
                .order('position', { ascending: true });
            if (error)
                throw new Error(error.message);
            return (data || []).map(this.formatPricing);
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM zone_pricing ORDER BY zone_key ASC, position ASC');
            return res.rows.map(this.formatPricing);
        }
        const store = db_1.db.getInMemoryStore();
        return [...(store.zone_pricing || [])]
            .sort((a, b) => a.zone_key.localeCompare(b.zone_key) || a.position - b.position)
            .map(this.formatPricing);
    }
    /**
     * Actualiza precio, duración, tier, posición, zona o estado de un puesto específico en zone_pricing
     */
    async updatePricing(id, payload) {
        const idNum = Number(id);
        if (!idNum || isNaN(idNum)) {
            throw new Error('ID de tarifa inválido');
        }
        const updateData = {};
        if (payload.zone_key !== undefined) {
            updateData.zone_key = String(payload.zone_key).toLowerCase().trim();
        }
        if (payload.position !== undefined) {
            const pos = Number(payload.position);
            if (isNaN(pos) || pos < 1 || pos > 10)
                throw new Error('La posición debe ser un número entre 1 y 10');
            updateData.position = pos;
        }
        if (payload.tier !== undefined) {
            const tierClean = String(payload.tier).toLowerCase().trim();
            updateData.tier = tierClean;
        }
        if (payload.price_usd !== undefined) {
            const price = Number(payload.price_usd);
            if (isNaN(price) || price < 0)
                throw new Error('El precio debe ser un número válido >= 0');
            updateData.price_usd = price;
        }
        if (payload.duration_hours !== undefined) {
            const duration = Math.round(Number(payload.duration_hours));
            if (isNaN(duration) || duration < 1 || duration > 720) {
                throw new Error('La duración debe estar entre 1 y 720 horas');
            }
            updateData.duration_hours = duration;
        }
        if (payload.is_active !== undefined) {
            updateData.is_active = Boolean(payload.is_active);
        }
        if (Object.keys(updateData).length === 0) {
            throw new Error('No se proporcionaron campos válidos para actualizar');
        }
        if (supabase_1.supabase) {
            let { data, error } = await supabase_1.supabase
                .from('zone_pricing')
                .update(updateData)
                .eq('id', idNum)
                .select()
                .maybeSingle();
            // Si por alguna razón de ID no coincide en Supabase, intentar por zona y posición
            if (!data && payload.zone_key && payload.position) {
                const fallback = await supabase_1.supabase
                    .from('zone_pricing')
                    .update(updateData)
                    .eq('zone_key', String(payload.zone_key).toLowerCase().trim())
                    .eq('position', Number(payload.position))
                    .select()
                    .maybeSingle();
                if (!fallback.error && fallback.data) {
                    data = fallback.data;
                    error = null;
                }
            }
            if (error) {
                console.error('❌ [Supabase Error updatePricing]:', error);
                throw new Error(`Error en Supabase: ${error.message}`);
            }
            if (!data)
                throw new Error(`Tarifa con ID ${id} no encontrada en la base de datos de Supabase`);
            return this.formatPricing(data);
        }
        if (db_1.db.isPostgresActive) {
            const setClauses = [];
            const values = [];
            let idx = 1;
            for (const [k, v] of Object.entries(updateData)) {
                setClauses.push(`${k} = $${idx}`);
                values.push(v);
                idx++;
            }
            values.push(idNum);
            const res = await db_1.db.query(`UPDATE zone_pricing SET ${setClauses.join(', ')} WHERE id = $${idx} RETURNING *`, values);
            if (res.rows.length === 0) {
                // Fallback si el ID no coincide exactamente pero tenemos zona y posición
                if (payload.zone_key && payload.position) {
                    const fbClauses = Object.keys(updateData).map((k, i) => `${k} = $${i + 1}`);
                    const fbValues = [...Object.values(updateData), String(payload.zone_key).toLowerCase().trim(), Number(payload.position)];
                    const fbRes = await db_1.db.query(`UPDATE zone_pricing SET ${fbClauses.join(', ')} WHERE zone_key = $${fbValues.length - 1} AND position = $${fbValues.length} RETURNING *`, fbValues);
                    if (fbRes.rows.length > 0)
                        return this.formatPricing(fbRes.rows[0]);
                }
                throw new Error(`Tarifa con ID ${id} no encontrada`);
            }
            return this.formatPricing(res.rows[0]);
        }
        const store = db_1.db.getInMemoryStore();
        let item = (store.zone_pricing || []).find((p) => Number(p.id) === idNum);
        if (!item && payload.zone_key && payload.position) {
            item = (store.zone_pricing || []).find((p) => p.zone_key === String(payload.zone_key).toLowerCase().trim() && Number(p.position) === Number(payload.position));
        }
        if (!item)
            throw new Error(`Tarifa con ID ${id} no encontrada`);
        Object.assign(item, updateData);
        return this.formatPricing(item);
    }
    /**
     * Crea una nueva tarifa en zone_pricing
     */
    async createPricing(payload) {
        if (!payload.zone_key)
            throw new Error('La zona es obligatoria');
        const zoneKey = String(payload.zone_key).toLowerCase().trim();
        const position = Number(payload.position);
        if (isNaN(position) || position < 1 || position > 10) {
            throw new Error('La posición debe ser un número entre 1 y 10');
        }
        const priceUsd = Number(payload.price_usd);
        if (isNaN(priceUsd) || priceUsd < 0) {
            throw new Error('El precio debe ser un número válido >= 0');
        }
        const durationHours = Math.round(Number(payload.duration_hours || 24));
        if (durationHours < 1 || durationHours > 720) {
            throw new Error('La duración debe estar entre 1 y 720 horas');
        }
        const tier = payload.tier
            ? String(payload.tier).toLowerCase().trim()
            : position === 1 ? 'gold' : position <= 3 ? 'silver' : 'dark';
        const isActive = payload.is_active !== undefined ? Boolean(payload.is_active) : true;
        if (supabase_1.supabase) {
            // 1. Verificar si ya existe para esta zona y posición
            const { data: existing } = await supabase_1.supabase
                .from('zone_pricing')
                .select('id')
                .eq('zone_key', zoneKey)
                .eq('position', position)
                .maybeSingle();
            if (existing && existing.id) {
                const { data: updated, error: updateError } = await supabase_1.supabase
                    .from('zone_pricing')
                    .update({
                    tier,
                    price_usd: priceUsd,
                    duration_hours: durationHours,
                    is_active: isActive
                })
                    .eq('id', existing.id)
                    .select()
                    .single();
                if (updateError) {
                    console.error('❌ [Supabase Error update existing in createPricing]:', updateError);
                    throw new Error(`Error en Supabase: ${updateError.message}`);
                }
                return this.formatPricing(updated);
            }
            // 2. Si no existe, insertar
            const { data, error } = await supabase_1.supabase
                .from('zone_pricing')
                .insert([{
                    zone_key: zoneKey,
                    position,
                    tier,
                    price_usd: priceUsd,
                    duration_hours: durationHours,
                    is_active: isActive
                }])
                .select()
                .single();
            if (error) {
                console.error('❌ [Supabase Error createPricing]:', error);
                throw new Error(`Error en Supabase: ${error.message}`);
            }
            return this.formatPricing(data);
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query(`INSERT INTO zone_pricing (zone_key, position, tier, price_usd, duration_hours, is_active)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (zone_key, position)
         DO UPDATE SET
           tier = EXCLUDED.tier,
           price_usd = EXCLUDED.price_usd,
           duration_hours = EXCLUDED.duration_hours,
           is_active = EXCLUDED.is_active
         RETURNING *`, [zoneKey, position, tier, priceUsd, durationHours, isActive]);
            return this.formatPricing(res.rows[0]);
        }
        const store = db_1.db.getInMemoryStore();
        if (!store.zone_pricing)
            store.zone_pricing = [];
        const existingIndex = store.zone_pricing.findIndex((p) => p.zone_key === zoneKey && Number(p.position) === position);
        if (existingIndex >= 0) {
            store.zone_pricing[existingIndex] = {
                ...store.zone_pricing[existingIndex],
                tier,
                price_usd: priceUsd,
                duration_hours: durationHours,
                is_active: isActive
            };
            return this.formatPricing(store.zone_pricing[existingIndex]);
        }
        const newId = store.zone_pricing.length > 0
            ? Math.max(...store.zone_pricing.map((p) => Number(p.id) || 0)) + 1
            : 1;
        const newItem = {
            id: newId,
            zone_key: zoneKey,
            position,
            tier,
            price_usd: priceUsd,
            duration_hours: durationHours,
            is_active: isActive
        };
        store.zone_pricing.push(newItem);
        return this.formatPricing(newItem);
    }
    /**
     * Elimina una tarifa de zone_pricing validando que no tenga una pauta activa protegida
     */
    async deletePricing(id) {
        const idNum = Number(id);
        if (!idNum || isNaN(idNum)) {
            throw new Error('ID de tarifa inválido');
        }
        // 1. Obtener la tarifa a eliminar para saber su zona y puesto
        let pricingItem = null;
        if (supabase_1.supabase) {
            const { data } = await supabase_1.supabase
                .from('zone_pricing')
                .select('*')
                .eq('id', idNum)
                .maybeSingle();
            if (data)
                pricingItem = this.formatPricing(data);
        }
        else if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM zone_pricing WHERE id = $1', [idNum]);
            if (res.rows.length > 0)
                pricingItem = this.formatPricing(res.rows[0]);
        }
        else {
            const store = db_1.db.getInMemoryStore();
            const found = (store.zone_pricing || []).find((p) => Number(p.id) === idNum);
            if (found)
                pricingItem = this.formatPricing(found);
        }
        if (!pricingItem) {
            throw new Error(`Tarifa con ID ${id} no encontrada`);
        }
        // 2. Comprobar si existe un anuncio activo real en ese puesto
        if (supabase_1.supabase) {
            const { data: activeAd } = await supabase_1.supabase
                .from('ranking')
                .select('id, business_name, is_active, payment_id')
                .eq('zone_key', pricingItem.zone_key)
                .eq('position', pricingItem.position)
                .eq('is_active', true)
                .not('payment_id', 'is', null)
                .maybeSingle();
            if (activeAd) {
                throw new Error(`No se puede eliminar la tarifa del puesto #${pricingItem.position} (${pricingItem.zone_key.toUpperCase()}) porque tiene un anuncio activo pagado: "${activeAd.business_name}". Desactiva o reasigna la pauta primero.`);
            }
            const { error } = await supabase_1.supabase
                .from('zone_pricing')
                .delete()
                .eq('id', idNum);
            if (error)
                throw new Error(error.message);
            return { id: idNum, message: `Tarifa #${pricingItem.position} (${pricingItem.zone_key}) eliminada exitosamente.` };
        }
        if (db_1.db.isPostgresActive) {
            const activeAdRes = await db_1.db.query(`SELECT id, business_name FROM ranking 
         WHERE zone_key = $1 AND position = $2 AND is_active = TRUE AND payment_id IS NOT NULL`, [pricingItem.zone_key, pricingItem.position]);
            if (activeAdRes.rows.length > 0) {
                throw new Error(`No se puede eliminar la tarifa del puesto #${pricingItem.position} (${pricingItem.zone_key.toUpperCase()}) porque tiene un anuncio activo pagado: "${activeAdRes.rows[0].business_name}".`);
            }
            await db_1.db.query('DELETE FROM zone_pricing WHERE id = $1', [idNum]);
            return { id: idNum, message: `Tarifa #${pricingItem.position} (${pricingItem.zone_key}) eliminada exitosamente.` };
        }
        const store = db_1.db.getInMemoryStore();
        const idx = (store.zone_pricing || []).findIndex((p) => Number(p.id) === idNum);
        if (idx !== -1) {
            store.zone_pricing.splice(idx, 1);
        }
        return { id: idNum, message: `Tarifa #${pricingItem.position} (${pricingItem.zone_key}) eliminada exitosamente.` };
    }
    formatZone(row) {
        return {
            id: Number(row.id),
            key: row.key,
            name: row.name,
            type: row.type,
            icon: row.icon || '📍',
            is_active: Boolean(row.is_active),
            sort_order: Number(row.sort_order || 0),
            created_at: row.created_at
        };
    }
    formatPricing(row) {
        return {
            id: Number(row.id),
            zone_key: row.zone_key,
            position: Number(row.position),
            tier: row.tier,
            price_usd: Number(row.price_usd),
            duration_hours: Number(row.duration_hours || 24),
            is_active: Boolean(row.is_active)
        };
    }
}
exports.ZonesService = ZonesService;
exports.zonesService = new ZonesService();
const getAllZones = () => exports.zonesService.getAllZones();
exports.getAllZones = getAllZones;
const getZonePricing = (zoneKey) => exports.zonesService.getZonePricing(zoneKey);
exports.getZonePricing = getZonePricing;
const getPriceForPosition = (zoneKey, position) => exports.zonesService.getPriceForPosition(zoneKey, position);
exports.getPriceForPosition = getPriceForPosition;
const getAllPricing = () => exports.zonesService.getAllPricing();
exports.getAllPricing = getAllPricing;
const updatePricing = (id, payload) => exports.zonesService.updatePricing(id, payload);
exports.updatePricing = updatePricing;
const createPricing = (payload) => exports.zonesService.createPricing(payload);
exports.createPricing = createPricing;
const deletePricing = (id) => exports.zonesService.deletePricing(id);
exports.deletePricing = deletePricing;
//# sourceMappingURL=zonesService.js.map