"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentService = exports.PaymentService = void 0;
const db_1 = require("../database/db");
const supabase_1 = require("../database/supabase");
const rankingService_1 = require("./rankingService");
const binancePayService_1 = require("./binancePayService");
const ratesService_1 = require("./ratesService");
const zonesService_1 = require("./zonesService");
const crypto_1 = require("crypto");
class PaymentService {
    /**
     * Crea una nueva orden de pago para pautar en el ranking (Binance Pay, Zinli o Zelle)
     */
    async createPaymentOrder(userId, data) {
        const paymentMethod = data.paymentMethod || 'binance';
        const zoneKey = (data.zoneKey || data.zone || 'nacional').toLowerCase().trim();
        const pricingInfo = await zonesService_1.zonesService.getPricingForPosition(zoneKey, data.position);
        const duration = data.durationHours || pricingInfo.duration_hours || 24;
        const expiresAt = new Date(Date.now() + duration * 3600 * 1000);
        const orderId = `VENFI_${Date.now()}_${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
        const zellePaymentId = (0, crypto_1.randomUUID)();
        const txHash = data.txHash || data.referenceCode || null;
        // Validar precio mínimo según zona y posición requerida
        const expectedAmount = pricingInfo.price_usd;
        const finalAmount = Math.max(data.amountUsd, expectedAmount);
        let paymentRecord;
        if (supabase_1.supabase) {
            const { data: insertedPayment, error: payError } = await supabase_1.supabase
                .from('payments')
                .insert([{
                    id: orderId,
                    user_id: userId || null,
                    amount_usd: finalAmount,
                    position: data.position,
                    duration_hours: duration,
                    status: 'pending',
                    payment_method: paymentMethod,
                    business_name: data.businessName,
                    target_url: data.targetUrl,
                    slogan: data.slogan,
                    category: data.category || 'General',
                    avatar: data.avatar || '🚀',
                    expires_at: expiresAt.toISOString(),
                    zone_key: zoneKey,
                    tx_hash: txHash
                }])
                .select()
                .single();
            if (payError)
                throw new Error(payError.message);
            paymentRecord = insertedPayment;
            if (paymentMethod === 'zelle' || paymentMethod === 'zinli') {
                const { error: zelleError } = await supabase_1.supabase
                    .from('zelle_payments')
                    .insert([{
                        id: zellePaymentId,
                        user_id: userId || null,
                        order_id: orderId,
                        amount_usd: finalAmount,
                        position: data.position,
                        status: 'pending',
                        created_at: new Date().toISOString()
                    }]);
                if (zelleError)
                    throw new Error(zelleError.message);
            }
        }
        else if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query(`INSERT INTO payments (id, user_id, amount_usd, position, duration_hours, status, payment_method, business_name, target_url, slogan, category, avatar, expires_at, zone_key, tx_hash)
         VALUES ($1, $2, $3, $4, $5, 'pending', $6, $7, $8, $9, $10, $11, $12, $13, $14)
         RETURNING *`, [
                orderId,
                userId || null,
                finalAmount,
                data.position,
                duration,
                paymentMethod,
                data.businessName,
                data.targetUrl,
                data.slogan,
                data.category || 'General',
                data.avatar || '🚀',
                expiresAt,
                zoneKey,
                txHash
            ]);
            paymentRecord = res.rows[0];
            // Si es Zelle o Zinli, registrar en la tabla zelle_payments
            if (paymentMethod === 'zelle' || paymentMethod === 'zinli') {
                await db_1.db.query(`INSERT INTO zelle_payments (id, user_id, order_id, amount_usd, position, status, created_at)
           VALUES ($1, $2, $3, $4, $5, 'pending', CURRENT_TIMESTAMP)`, [zellePaymentId, userId || null, orderId, finalAmount, data.position]);
            }
        }
        else {
            const store = db_1.db.getInMemoryStore();
            paymentRecord = {
                id: orderId,
                user_id: userId || null,
                amount_usd: finalAmount,
                position: data.position,
                duration_hours: duration,
                status: 'pending',
                payment_method: paymentMethod,
                tx_hash: txHash,
                business_name: data.businessName,
                target_url: data.targetUrl,
                slogan: data.slogan,
                category: data.category || 'General',
                avatar: data.avatar || '🚀',
                created_at: new Date().toISOString(),
                expires_at: expiresAt.toISOString(),
                zone_key: zoneKey
            };
            store.payments.push(paymentRecord);
            if (paymentMethod === 'zelle' || paymentMethod === 'zinli') {
                store.zelle_payments.push({
                    id: zellePaymentId,
                    user_id: userId || null,
                    order_id: orderId,
                    amount_usd: finalAmount,
                    position: data.position,
                    reference_code: null,
                    proof_image_url: null,
                    status: 'pending',
                    admin_notes: null,
                    created_at: new Date().toISOString(),
                    verified_at: null,
                    completed_at: null
                });
            }
        }
        // Procesar según método de pago
        if (paymentMethod === 'binance') {
            const binanceOrder = await binancePayService_1.binancePayService.createOrder({
                merchantTradeNo: orderId,
                orderAmount: finalAmount,
                currency: 'USDT',
                goodsName: `Venfidata Publicidad Ranking #${data.position}`,
                goodsDetail: data.slogan,
                userId
            });
            return {
                success: true,
                paymentId: paymentRecord.id,
                orderId,
                amountUsd: finalAmount,
                currency: 'USDT',
                paymentMethod: 'binance',
                binancePay: binanceOrder,
                message: 'Orden comercial de Binance Pay generada exitosamente. Escanea el código QR o abre Binance App.'
            };
        }
        else if (paymentMethod === 'zinli') {
            return {
                success: true,
                paymentId: paymentRecord.id,
                orderId,
                zellePaymentId,
                amountUsd: finalAmount,
                currency: 'USD',
                paymentMethod: 'zinli',
                zinliInfo: {
                    recipientEmail: 'miplan3d@gmail.com',
                    accountHolder: 'Venfidata Publicidad',
                    referenceNote: orderId,
                    amount: finalAmount,
                    instructions: 'Envía el monto exacto vía Zinli al correo miplan3d@gmail.com. Luego reporta tu número de referencia.'
                },
                message: 'Datos de Zinli generados. Reporta tu comprobante para activación.'
            };
        }
        else if (paymentMethod === 'crypto') {
            const { settingsService } = await Promise.resolve().then(() => __importStar(require('./settingsService')));
            const cryptoSettings = await settingsService.getPaymentSettingByKey('crypto');
            const wallet = cryptoSettings?.wallet || '0x71C83893F79328B5945864112e367800F8912387';
            const network = cryptoSettings?.network || 'USDT (TRC-20 / BEP-20)';
            return {
                success: true,
                paymentId: paymentRecord.id,
                orderId,
                amountUsd: finalAmount,
                amountUsdt: finalAmount,
                currency: 'USDT',
                paymentMethod: 'crypto',
                status: 'pending',
                txHash: txHash,
                cryptoInfo: {
                    wallet,
                    network,
                    amountUsdt: finalAmount,
                    txHash: txHash,
                    instructions: `Transfiere exactamente ${finalAmount} USDT (${network}) a la wallet: ${wallet}. Luego ingresa el hash (TXID) de la transacción.`
                },
                message: 'Orden en Criptomonedas (USDT) generada exitosamente. Estado pendiente de verificación.'
            };
        }
        else {
            return {
                success: true,
                paymentId: paymentRecord.id,
                orderId,
                zellePaymentId,
                amountUsd: finalAmount,
                currency: 'USD',
                paymentMethod: 'zelle',
                zelleInfo: {
                    recipientEmail: 'soporte@venfidata.com',
                    accountHolder: 'Venfidata Media LLC',
                    referenceNote: orderId,
                    amount: finalAmount,
                    instructions: 'Envía el monto exacto vía Zelle colocando tu Order ID en el campo de nota de la transferencia. Luego reporta tu número de referencia.'
                },
                message: 'Datos de transferencia Zelle generados. Reporta tu comprobante para activación.'
            };
        }
    }
    /**
     * Procesa el Webhook de Binance Pay y activa la pauta en el ranking
     */
    async processWebhook(payload, headers) {
        const orderId = payload.merchantTradeNo || payload.orderId || payload.bizId || payload.data?.merchantTradeNo;
        const txHash = payload.txHash || payload.data?.transactionId || `TX_${Date.now()}_BINANCE`;
        const tradeStatus = payload.tradeStatus || payload.data?.status || 'SUCCESS';
        if (tradeStatus !== 'SUCCESS' && tradeStatus !== 'PAID') {
            return { success: false, message: `Estado de pago no completado: ${tradeStatus}` };
        }
        let payment;
        if (supabase_1.supabase) {
            if (orderId) {
                const { data: exactMatch } = await supabase_1.supabase
                    .from('payments')
                    .select('*')
                    .eq('id', orderId)
                    .maybeSingle();
                payment = exactMatch;
                if (!payment) {
                    const { data: likeMatches } = await supabase_1.supabase
                        .from('payments')
                        .select('*')
                        .ilike('id', `%${orderId}%`)
                        .limit(1);
                    payment = likeMatches?.[0];
                }
            }
            if (!payment) {
                const { data: latestPending } = await supabase_1.supabase
                    .from('payments')
                    .select('*')
                    .eq('status', 'pending')
                    .order('created_at', { ascending: false })
                    .limit(1);
                payment = latestPending?.[0];
            }
            if (payment) {
                await supabase_1.supabase
                    .from('payments')
                    .update({ status: 'completed', tx_hash: txHash })
                    .eq('id', payment.id);
                await rankingService_1.rankingService.placeAdInRanking({
                    userId: payment.user_id,
                    paymentId: payment.id,
                    position: payment.position,
                    businessName: payment.business_name,
                    targetUrl: payment.target_url,
                    slogan: payment.slogan,
                    category: payment.category,
                    avatar: payment.avatar,
                    amountPaid: Number(payment.amount_usd),
                    durationHours: payment.duration_hours,
                    zoneKey: payment.zone_key || 'nacional'
                });
                if (payment.user_id) {
                    await supabase_1.supabase
                        .from('notifications')
                        .insert([{
                            user_id: payment.user_id,
                            message: `¡Pago verificado! Tu anuncio '${payment.business_name}' ya está en el puesto #${payment.position} del Ranking.`,
                            type: 'payment'
                        }]);
                }
                return {
                    success: true,
                    message: 'Pago de Binance Pay verificado exitosamente y ranking actualizado.',
                    orderId: payment.id,
                    position: payment.position,
                    businessName: payment.business_name
                };
            }
        }
        else if (db_1.db.isPostgresActive) {
            let res = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1 OR id::text LIKE $2 LIMIT 1', [orderId, `%${orderId}%`]);
            payment = res.rows[0];
            if (!payment) {
                const latestRes = await db_1.db.query("SELECT * FROM payments WHERE status = 'pending' ORDER BY created_at DESC LIMIT 1");
                payment = latestRes.rows[0];
            }
            if (payment) {
                // Actualizar estado a completed
                await db_1.db.query("UPDATE payments SET status = 'completed', tx_hash = $1 WHERE id = $2", [txHash, payment.id]);
                // Desplegar anuncio en el Ranking
                await rankingService_1.rankingService.placeAdInRanking({
                    userId: payment.user_id,
                    paymentId: payment.id,
                    position: payment.position,
                    businessName: payment.business_name,
                    targetUrl: payment.target_url,
                    slogan: payment.slogan,
                    category: payment.category,
                    avatar: payment.avatar,
                    amountPaid: Number(payment.amount_usd),
                    durationHours: payment.duration_hours,
                    zoneKey: payment.zone_key || 'nacional'
                });
                // Crear notificación de confirmación
                if (payment.user_id) {
                    await db_1.db.query("INSERT INTO notifications (user_id, message, type) VALUES ($1, $2, 'payment')", [payment.user_id, `¡Pago verificado! Tu anuncio '${payment.business_name}' ya está en el puesto #${payment.position} del Ranking.`]);
                }
                return {
                    success: true,
                    message: 'Pago de Binance Pay verificado exitosamente y ranking actualizado.',
                    orderId: payment.id,
                    position: payment.position,
                    businessName: payment.business_name
                };
            }
        }
        // Modo Memoria
        const store = db_1.db.getInMemoryStore();
        payment = store.payments.find(p => p.id === orderId || (typeof orderId === 'string' && p.id.includes(orderId)));
        if (!payment && store.payments.length > 0) {
            payment = store.payments[store.payments.length - 1]; // Toma el más reciente para testing
        }
        if (payment) {
            payment.status = 'completed';
            payment.tx_hash = txHash;
            await rankingService_1.rankingService.placeAdInRanking({
                userId: payment.user_id,
                paymentId: payment.id,
                position: payment.position,
                businessName: payment.business_name,
                targetUrl: payment.target_url,
                slogan: payment.slogan,
                category: payment.category,
                avatar: payment.avatar,
                amountPaid: Number(payment.amount_usd),
                durationHours: payment.duration_hours,
                zoneKey: payment.zone_key || 'nacional'
            });
            if (payment.user_id) {
                store.notifications.push({
                    id: `notif_${Date.now()}`,
                    user_id: payment.user_id,
                    message: `¡Pago verificado! Tu anuncio '${payment.business_name}' ya está en el puesto #${payment.position} del Ranking.`,
                    type: 'payment',
                    created_at: new Date().toISOString(),
                    is_read: false
                });
            }
            return {
                success: true,
                message: 'Pago de Binance Pay verificado exitosamente y ranking actualizado.',
                orderId: payment.id,
                position: payment.position,
                businessName: payment.business_name
            };
        }
        return { success: false, message: 'No se encontró la orden de pago asociada.' };
    }
    /**
     * Consulta el estado de una orden de pago
     */
    async getPaymentStatus(orderId) {
        if (supabase_1.supabase) {
            const { data, error } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .eq('id', orderId)
                .maybeSingle();
            if (error)
                throw new Error(error.message);
            if (!data) {
                throw new Error('Orden no encontrada');
            }
            return data;
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1', [orderId]);
            if (res.rows.length === 0) {
                throw new Error('Orden no encontrada');
            }
            return res.rows[0];
        }
        const store = db_1.db.getInMemoryStore();
        const payment = store.payments.find(p => p.id === orderId);
        if (!payment) {
            throw new Error('Orden no encontrada');
        }
        return payment;
    }
    /**
     * Permite al usuario reportar comprobante y código de referencia Zelle
     */
    async submitZelleProof(orderId, referenceCode, proofImageUrl) {
        if (supabase_1.supabase) {
            const { error: zelleError } = await supabase_1.supabase
                .from('zelle_payments')
                .update({
                reference_code: referenceCode,
                proof_image_url: proofImageUrl || null,
                status: 'pending'
            })
                .eq('order_id', orderId);
            if (zelleError)
                throw new Error(zelleError.message);
            const { error: payError } = await supabase_1.supabase
                .from('payments')
                .update({ status: 'pending', tx_hash: referenceCode })
                .eq('id', orderId);
            if (payError)
                throw new Error(payError.message);
            return {
                success: true,
                message: 'Comprobante Zelle registrado exitosamente. Nuestro equipo administrativo verificará la transacción en minutos.'
            };
        }
        if (db_1.db.isPostgresActive) {
            await db_1.db.query(`UPDATE zelle_payments 
         SET reference_code = $1, proof_image_url = $2, status = 'pending'
         WHERE order_id = $3`, [referenceCode, proofImageUrl || null, orderId]);
            await db_1.db.query("UPDATE payments SET status = 'pending', tx_hash = $1 WHERE id::text = $2", [referenceCode, orderId]);
            return {
                success: true,
                message: 'Comprobante Zelle registrado exitosamente. Nuestro equipo administrativo verificará la transacción en minutos.'
            };
        }
        const store = db_1.db.getInMemoryStore();
        let zelle = store.zelle_payments.find(z => z.order_id === orderId);
        if (!zelle) {
            zelle = {
                id: (0, crypto_1.randomUUID)(),
                user_id: null,
                order_id: orderId,
                amount_usd: 15.00,
                position: 1,
                reference_code: referenceCode,
                proof_image_url: proofImageUrl || null,
                status: 'pending',
                admin_notes: null,
                created_at: new Date().toISOString(),
                verified_at: null,
                completed_at: null
            };
            store.zelle_payments.push(zelle);
        }
        else {
            zelle.reference_code = referenceCode;
            zelle.proof_image_url = proofImageUrl || null;
            zelle.status = 'pending';
        }
        const payment = store.payments.find(p => p.id === orderId);
        if (payment) {
            payment.status = 'pending';
            payment.tx_hash = referenceCode;
        }
        return {
            success: true,
            message: 'Comprobante Zelle registrado exitosamente. Nuestro equipo administrativo verificará la transacción en minutos.'
        };
    }
    /**
     * Obtiene la lista de pagos Zelle pendientes de verificación para el panel administrativo
     */
    async getPendingZellePayments() {
        if (supabase_1.supabase) {
            const { data: zelles, error } = await supabase_1.supabase
                .from('zelle_payments')
                .select('*')
                .in('status', ['pending', 'verified'])
                .order('created_at', { ascending: false });
            if (error)
                throw new Error(error.message);
            if (!zelles || zelles.length === 0)
                return [];
            const orderIds = Array.from(new Set(zelles.map((z) => z.order_id).filter(Boolean)));
            const userIds = Array.from(new Set(zelles.map((z) => z.user_id).filter(Boolean)));
            const { data: payments } = orderIds.length
                ? await supabase_1.supabase.from('payments').select('id, business_name, target_url, slogan, category, avatar').in('id', orderIds)
                : { data: [] };
            const { data: users } = userIds.length
                ? await supabase_1.supabase.from('users').select('id, email').in('id', userIds)
                : { data: [] };
            const paymentMap = new Map((payments || []).map((p) => [String(p.id), p]));
            const userMap = new Map((users || []).map((u) => [String(u.id), u]));
            return zelles
                .filter((z) => paymentMap.has(String(z.order_id)))
                .map((z) => {
                const p = paymentMap.get(String(z.order_id));
                const u = z.user_id ? userMap.get(String(z.user_id)) : null;
                return {
                    ...z,
                    business_name: p.business_name,
                    target_url: p.target_url,
                    slogan: p.slogan,
                    category: p.category,
                    avatar: p.avatar,
                    user_email: u?.email || null
                };
            });
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query(`SELECT z.*, p.business_name, p.target_url, p.slogan, p.category, p.avatar, u.email as user_email
         FROM zelle_payments z
         JOIN payments p ON z.order_id = p.id::text
         LEFT JOIN users u ON z.user_id = u.id
         WHERE z.status IN ('pending', 'verified')
         ORDER BY z.created_at DESC`);
            return res.rows;
        }
        const store = db_1.db.getInMemoryStore();
        return store.zelle_payments.map(z => {
            const payment = store.payments.find(p => p.id === z.order_id) || {};
            const user = store.users.find(u => u.id === z.user_id) || {};
            return {
                ...z,
                business_name: payment.business_name || 'Anunciante Venfidata',
                target_url: payment.target_url || 'https://venfidata.com',
                slogan: payment.slogan || 'Campaña publicitaria',
                category: payment.category || 'General',
                avatar: payment.avatar || '🚀',
                user_email: user.email || 'anunciante@venfidata.com'
            };
        });
    }
    /**
     * Conciliación y verificación manual de pago Zelle por parte de un Administrador
     */
    async verifyZellePaymentAdmin(orderId, isApproved, adminNotes) {
        const now = new Date();
        const finalStatus = isApproved ? 'completed' : 'rejected';
        if (supabase_1.supabase) {
            const { data: payment, error: payFetchErr } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .eq('id', orderId)
                .maybeSingle();
            if (payFetchErr)
                throw new Error(payFetchErr.message);
            if (!payment) {
                throw new Error('Orden de pago no encontrada');
            }
            const { error: zelleUpdateErr } = await supabase_1.supabase
                .from('zelle_payments')
                .update({
                status: finalStatus,
                admin_notes: adminNotes || (isApproved ? 'Aprobado manualmente' : 'Rechazado por fondos no recibidos'),
                verified_at: now.toISOString(),
                completed_at: isApproved ? now.toISOString() : null
            })
                .eq('order_id', orderId);
            if (zelleUpdateErr)
                throw new Error(zelleUpdateErr.message);
            const { error: payUpdateErr } = await supabase_1.supabase
                .from('payments')
                .update({ status: finalStatus })
                .eq('id', orderId);
            if (payUpdateErr)
                throw new Error(payUpdateErr.message);
            if (isApproved) {
                await rankingService_1.rankingService.placeAdInRanking({
                    userId: payment.user_id,
                    paymentId: payment.id,
                    position: payment.position,
                    businessName: payment.business_name,
                    targetUrl: payment.target_url,
                    slogan: payment.slogan,
                    category: payment.category,
                    avatar: payment.avatar,
                    amountPaid: Number(payment.amount_usd),
                    durationHours: payment.duration_hours,
                    zoneKey: payment.zone_key || 'nacional'
                });
                if (payment.user_id) {
                    await supabase_1.supabase.from('notifications').insert([{
                            user_id: payment.user_id,
                            message: `¡Transferencia Zelle verificada! Tu anuncio '${payment.business_name}' ha sido activado en el puesto #${payment.position} del Ranking.`,
                            type: 'payment'
                        }]);
                }
            }
            else if (payment.user_id) {
                await supabase_1.supabase.from('notifications').insert([{
                        user_id: payment.user_id,
                        message: `Tu pago Zelle para '${payment.business_name}' fue rechazado. Motivo: ${adminNotes || 'Referencia no encontrada en cuenta bancaria.'}`,
                        type: 'alert'
                    }]);
            }
            return {
                success: true,
                status: finalStatus,
                orderId,
                message: isApproved ? 'Pago Zelle aprobado y pauta activada en el ranking.' : 'Pago Zelle rechazado.'
            };
        }
        if (db_1.db.isPostgresActive) {
            const zelleRes = await db_1.db.query('SELECT * FROM zelle_payments WHERE order_id = $1', [orderId]);
            const paymentRes = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1', [orderId]);
            if (paymentRes.rows.length === 0) {
                throw new Error('Orden de pago no encontrada');
            }
            const payment = paymentRes.rows[0];
            // Actualizar tabla zelle_payments
            await db_1.db.query(`UPDATE zelle_payments 
         SET status = $1, admin_notes = $2, verified_at = $3, completed_at = $4
         WHERE order_id = $5`, [finalStatus, adminNotes || (isApproved ? 'Aprobado manualmente' : 'Rechazado por fondos no recibidos'), now, isApproved ? now : null, orderId]);
            // Actualizar tabla payments
            await db_1.db.query('UPDATE payments SET status = $1 WHERE id::text = $2', [finalStatus, orderId]);
            if (isApproved) {
                // Desplegar pauta en el Ranking
                await rankingService_1.rankingService.placeAdInRanking({
                    userId: payment.user_id,
                    paymentId: payment.id,
                    position: payment.position,
                    businessName: payment.business_name,
                    targetUrl: payment.target_url,
                    slogan: payment.slogan,
                    category: payment.category,
                    avatar: payment.avatar,
                    amountPaid: Number(payment.amount_usd),
                    durationHours: payment.duration_hours,
                    zoneKey: payment.zone_key || 'nacional'
                });
                // Crear notificación para el usuario
                if (payment.user_id) {
                    await db_1.db.query("INSERT INTO notifications (user_id, message, type) VALUES ($1, $2, 'payment')", [payment.user_id, `¡Transferencia Zelle verificada! Tu anuncio '${payment.business_name}' ha sido activado en el puesto #${payment.position} del Ranking.`]);
                }
            }
            else {
                // Notificar rechazo
                if (payment.user_id) {
                    await db_1.db.query("INSERT INTO notifications (user_id, message, type) VALUES ($1, $2, 'alert')", [payment.user_id, `Tu pago Zelle para '${payment.business_name}' fue rechazado. Motivo: ${adminNotes || 'Referencia no encontrada en cuenta bancaria.'}`]);
                }
            }
            return {
                success: true,
                status: finalStatus,
                orderId,
                message: isApproved ? 'Pago Zelle aprobado y pauta activada en el ranking.' : 'Pago Zelle rechazado.'
            };
        }
        // Modo Memoria
        const store = db_1.db.getInMemoryStore();
        const zelle = store.zelle_payments.find(z => z.order_id === orderId);
        const payment = store.payments.find(p => p.id === orderId);
        if (zelle) {
            zelle.status = finalStatus;
            zelle.admin_notes = adminNotes || (isApproved ? 'Aprobado manualmente' : 'Rechazado');
            zelle.verified_at = now.toISOString();
            if (isApproved)
                zelle.completed_at = now.toISOString();
        }
        if (payment) {
            payment.status = finalStatus;
            if (isApproved) {
                await rankingService_1.rankingService.placeAdInRanking({
                    userId: payment.user_id,
                    paymentId: payment.id,
                    position: payment.position,
                    businessName: payment.business_name,
                    targetUrl: payment.target_url,
                    slogan: payment.slogan,
                    category: payment.category,
                    avatar: payment.avatar,
                    amountPaid: Number(payment.amount_usd),
                    durationHours: payment.duration_hours
                });
                if (payment.user_id) {
                    store.notifications.push({
                        id: `notif_${Date.now()}`,
                        user_id: payment.user_id,
                        message: `¡Transferencia Zelle verificada! Tu anuncio '${payment.business_name}' ha sido activado en el puesto #${payment.position} del Ranking.`,
                        type: 'payment',
                        created_at: new Date().toISOString(),
                        is_read: false
                    });
                }
            }
            else {
                if (payment.user_id) {
                    store.notifications.push({
                        id: `notif_${Date.now()}`,
                        user_id: payment.user_id,
                        message: `Tu pago Zelle para '${payment.business_name}' fue rechazado. Motivo: ${adminNotes || 'Referencia no encontrada en cuenta bancaria.'}`,
                        type: 'alert',
                        created_at: new Date().toISOString(),
                        is_read: false
                    });
                }
            }
        }
        return {
            success: true,
            status: finalStatus,
            orderId,
            message: isApproved ? 'Pago Zelle aprobado y pauta activada en el ranking.' : 'Pago Zelle rechazado.'
        };
    }
    /**
     * Procesa la renovación de una pauta activa en el ranking extendiendo su duración
     */
    async renewCampaign(userId, data) {
        const duration = data.durationHours || 24;
        const expectedAmount = data.position === 1 ? 15.00 : (data.position <= 3 ? 10.00 : 5.00);
        const orderId = `VENFI_RENEW_${Date.now()}_${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
        // Obtener detalles de la pauta existente
        let businessName = 'Anuncio Renovado';
        let targetUrl = 'https://venfidata.com';
        let slogan = 'Pauta publicitaria extendida en Venfidata';
        let avatar = '🚀';
        let category = 'General';
        if (supabase_1.supabase && data.paymentId) {
            const { data: p } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .eq('id', data.paymentId)
                .maybeSingle();
            if (p) {
                businessName = p.business_name;
                targetUrl = p.target_url;
                slogan = p.slogan;
                avatar = p.avatar;
                category = p.category;
            }
        }
        else if (db_1.db.isPostgresActive && data.paymentId) {
            const res = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1', [data.paymentId]);
            if (res.rows.length > 0) {
                const p = res.rows[0];
                businessName = p.business_name;
                targetUrl = p.target_url;
                slogan = p.slogan;
                avatar = p.avatar;
                category = p.category;
            }
        }
        return this.createPaymentOrder(userId, {
            position: data.position,
            amountUsd: expectedAmount,
            durationHours: duration,
            businessName,
            targetUrl,
            slogan,
            avatar,
            category,
            paymentMethod: data.paymentMethod || 'binance'
        });
    }
    pagoMovilBankData = {
        bank: 'BNC (Banco Nacional de Crédito)',
        bankCode: '0191',
        phone: '0412-4160819',
        idNumber: 'V-11112387',
        beneficiaryName: 'Venfidata Publicidad & Medios C.A.'
    };
    getPagoMovilBankData() {
        return this.pagoMovilBankData;
    }
    updatePagoMovilBankData(data) {
        this.pagoMovilBankData = { ...this.pagoMovilBankData, ...data };
        return this.pagoMovilBankData;
    }
    /**
     * 1. Solicita una orden de pago en Bolívares (VES) usando Pago Móvil
     */
    async createPagoMovilOrder(userId, orderData) {
        const zoneKey = (orderData.zoneKey || orderData.zone_key || 'nacional').toLowerCase();
        const pricingInfo = await zonesService_1.zonesService.getPricingForPosition(zoneKey, orderData.position);
        const duration = orderData.durationHours || pricingInfo.duration_hours || 24;
        const expiresAt = new Date(Date.now() + duration * 3600 * 1000);
        const orderId = `VENFI_PM_${Date.now()}_${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
        // Validar monto mínimo según zona y puesto requerido
        const expectedAmount = pricingInfo.price_usd;
        const finalAmountUsd = Math.max(orderData.amountUsd || expectedAmount, expectedAmount);
        // Obtener tasa BCV oficial
        const bcvRate = await ratesService_1.ratesService.getBcvRate();
        const amountVes = Number((finalAmountUsd * bcvRate).toFixed(2));
        let paymentRecord;
        if (supabase_1.supabase) {
            const { data: insertedPayment, error: payError } = await supabase_1.supabase
                .from('payments')
                .insert([{
                    id: orderId,
                    user_id: userId || null,
                    amount_usd: finalAmountUsd,
                    position: orderData.position,
                    duration_hours: duration,
                    status: 'pending',
                    payment_method: 'pago_movil',
                    business_name: orderData.businessName,
                    target_url: orderData.targetUrl,
                    slogan: orderData.slogan,
                    category: orderData.category || 'General',
                    avatar: orderData.avatar || '🚀',
                    expires_at: expiresAt.toISOString(),
                    zone_key: zoneKey
                }])
                .select()
                .single();
            if (payError)
                throw new Error(payError.message);
            paymentRecord = insertedPayment;
        }
        else if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query(`INSERT INTO payments (
          id, user_id, amount_usd, position, duration_hours, status, payment_method, 
          business_name, target_url, slogan, category, avatar, expires_at, zone_key
        ) VALUES ($1, $2, $3, $4, $5, 'pending', 'pago_movil', $6, $7, $8, $9, $10, $11, $12)
        RETURNING *`, [
                orderId,
                userId || null,
                finalAmountUsd,
                orderData.position,
                duration,
                orderData.businessName,
                orderData.targetUrl,
                orderData.slogan,
                orderData.category || 'General',
                orderData.avatar || '🚀',
                expiresAt,
                zoneKey
            ]);
            paymentRecord = res.rows[0];
        }
        else {
            const store = db_1.db.getInMemoryStore();
            paymentRecord = {
                id: orderId,
                user_id: userId || null,
                amount_usd: finalAmountUsd,
                position: orderData.position,
                duration_hours: duration,
                status: 'pending',
                payment_method: 'pago_movil',
                tx_hash: null,
                reference_number: null,
                proof_image_url: null,
                business_name: orderData.businessName,
                target_url: orderData.targetUrl,
                slogan: orderData.slogan,
                category: orderData.category || 'General',
                avatar: orderData.avatar || '🚀',
                created_at: new Date().toISOString(),
                expires_at: expiresAt.toISOString(),
                zone_key: zoneKey
            };
            store.payments.push(paymentRecord);
        }
        const cleanPhone = this.pagoMovilBankData.phone.replace(/[^0-9]/g, '');
        const cleanId = this.pagoMovilBankData.idNumber.replace(/[^0-9a-zA-Z]/g, '').toUpperCase();
        const qrPayload = `PAGOMOVIL|${this.pagoMovilBankData.bankCode}|${cleanPhone}|${cleanId}|${amountVes}|${orderId}`;
        let qrImage = '';
        try {
            const QRCode = await Promise.resolve().then(() => __importStar(require('qrcode')));
            qrImage = await QRCode.toDataURL(qrPayload, {
                errorCorrectionLevel: 'M',
                margin: 2,
                color: { dark: '#030712', light: '#ffffff' },
                width: 320
            });
        }
        catch (e) {
            console.warn('Error al generar QR de Pago Móvil en create:', e);
        }
        return {
            orderId,
            amountUsd: finalAmountUsd,
            amountVes,
            bcvRate,
            bankData: this.getPagoMovilBankData(),
            qrPayload,
            qrImage,
            payment: paymentRecord
        };
    }
    /**
     * Genera el código QR dinámico y payload interbancario de Pago Móvil para una orden
     */
    async generatePagoMovilQR(orderId) {
        let payment;
        if (supabase_1.supabase) {
            const { data, error } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .eq('id', orderId)
                .maybeSingle();
            if (error)
                throw new Error(error.message);
            if (!data) {
                throw new Error('Orden de Pago Móvil no encontrada.');
            }
            payment = data;
        }
        else if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1', [orderId]);
            if (res.rows.length === 0) {
                throw new Error('Orden de Pago Móvil no encontrada.');
            }
            payment = res.rows[0];
        }
        else {
            const store = db_1.db.getInMemoryStore();
            payment = store.payments.find(p => p.id === orderId);
            if (!payment) {
                throw new Error('Orden de Pago Móvil no encontrada.');
            }
        }
        const bcvRate = await ratesService_1.ratesService.getBcvRate();
        const amountUsd = Number(payment.amount_usd);
        const amountVes = Number((amountUsd * bcvRate).toFixed(2));
        const bankData = this.getPagoMovilBankData();
        const cleanPhone = bankData.phone.replace(/[^0-9]/g, '');
        const cleanId = bankData.idNumber.replace(/[^0-9a-zA-Z]/g, '').toUpperCase();
        const qrPayload = `PAGOMOVIL|${bankData.bankCode}|${cleanPhone}|${cleanId}|${amountVes}|${orderId}`;
        const QRCode = await Promise.resolve().then(() => __importStar(require('qrcode')));
        const qrImage = await QRCode.toDataURL(qrPayload, {
            errorCorrectionLevel: 'M',
            margin: 2,
            color: {
                dark: '#030712',
                light: '#ffffff'
            },
            width: 320
        });
        return {
            orderId,
            amountUsd,
            amountVes,
            bcvRate,
            bankData,
            qrPayload,
            qrImage
        };
    }
    /**
     * 2. Registra el comprobante de pago móvil (número de referencia y captura)
     */
    async uploadPagoMovilProof(orderId, referenceNumber, proofImageUrl) {
        if (!orderId || !referenceNumber) {
            throw new Error('El ID de orden y el número de referencia son obligatorios.');
        }
        if (supabase_1.supabase) {
            const { data: current, error: fetchErr } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .eq('id', orderId)
                .maybeSingle();
            if (fetchErr)
                throw new Error(fetchErr.message);
            if (!current) {
                throw new Error('Orden de Pago Móvil no encontrada.');
            }
            if (current.status !== 'pending') {
                throw new Error(`La orden ya ha sido procesada con estado: ${current.status}`);
            }
            const { data: updated, error: updateErr } = await supabase_1.supabase
                .from('payments')
                .update({
                reference_number: referenceNumber.trim(),
                proof_image_url: proofImageUrl || null,
                tx_hash: referenceNumber.trim()
            })
                .eq('id', orderId)
                .select()
                .single();
            if (updateErr)
                throw new Error(updateErr.message);
            return {
                success: true,
                message: 'Comprobante registrado exitosamente. Nuestro equipo administrativo verificará la transacción en minutos.',
                data: updated
            };
        }
        if (db_1.db.isPostgresActive) {
            const checkRes = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1', [orderId]);
            if (checkRes.rows.length === 0) {
                throw new Error('Orden de Pago Móvil no encontrada.');
            }
            const current = checkRes.rows[0];
            if (current.status !== 'pending') {
                throw new Error(`La orden ya ha sido procesada con estado: ${current.status}`);
            }
            const updateRes = await db_1.db.query(`UPDATE payments 
         SET reference_number = $1, proof_image_url = $2, tx_hash = $1
         WHERE id::text = $3
         RETURNING *`, [referenceNumber.trim(), proofImageUrl || null, orderId]);
            return {
                success: true,
                message: 'Comprobante registrado exitosamente. Nuestro equipo administrativo verificará la transacción en minutos.',
                data: updateRes.rows[0]
            };
        }
        const store = db_1.db.getInMemoryStore();
        const payment = store.payments.find(p => p.id === orderId);
        if (!payment) {
            throw new Error('Orden de Pago Móvil no encontrada.');
        }
        if (payment.status !== 'pending') {
            throw new Error(`La orden ya ha sido procesada con estado: ${payment.status}`);
        }
        payment.reference_number = referenceNumber.trim();
        payment.proof_image_url = proofImageUrl || null;
        payment.tx_hash = referenceNumber.trim();
        return {
            success: true,
            message: 'Comprobante registrado exitosamente. Nuestro equipo administrativo verificará la transacción en minutos.',
            data: payment
        };
    }
    /**
     * 3. Devuelve todas las órdenes con payment_method = 'pago_movil' y status = 'pending'
     */
    async listPagoMovilPending() {
        if (supabase_1.supabase) {
            const { data: pending, error } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .in('payment_method', ['pago_movil', 'pagomovil'])
                .eq('status', 'pending')
                .order('created_at', { ascending: false });
            if (error)
                throw new Error(error.message);
            if (!pending || pending.length === 0)
                return [];
            const userIds = Array.from(new Set(pending.map((p) => p.user_id).filter(Boolean)));
            const { data: users } = userIds.length
                ? await supabase_1.supabase.from('users').select('id, email, username').in('id', userIds)
                : { data: [] };
            const userMap = new Map((users || []).map((u) => [String(u.id), u]));
            return pending.map((p) => {
                const u = p.user_id ? userMap.get(String(p.user_id)) : null;
                return {
                    ...p,
                    user_email: u?.email || null,
                    user_username: u?.username || null
                };
            });
        }
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query(`SELECT p.*, u.email as user_email, u.username as user_username
         FROM payments p
         LEFT JOIN users u ON p.user_id = u.id
         WHERE p.payment_method IN ('pago_movil', 'pagomovil') AND p.status = 'pending'
         ORDER BY p.created_at DESC`);
            return res.rows;
        }
        const store = db_1.db.getInMemoryStore();
        return store.payments
            .filter(p => (p.payment_method === 'pago_movil' || p.payment_method === 'pagomovil') && p.status === 'pending')
            .map(p => {
            const user = store.users.find(u => u.id === p.user_id) || {};
            return {
                ...p,
                user_email: user.email || 'anunciante@venfidata.com',
                user_username: user.username || 'Anunciante'
            };
        });
    }
    /**
     * 4. Aprueba una orden de Pago Móvil y activa la pauta en el ranking
     */
    async approvePagoMovil(orderId, adminNotes) {
        if (supabase_1.supabase) {
            const { data: payment, error: fetchErr } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .eq('id', orderId)
                .maybeSingle();
            if (fetchErr)
                throw new Error(fetchErr.message);
            if (!payment) {
                throw new Error('Orden de pago no encontrada.');
            }
            const { error: updateErr } = await supabase_1.supabase
                .from('payments')
                .update({ status: 'completed' })
                .eq('id', orderId);
            if (updateErr)
                throw new Error(updateErr.message);
            await rankingService_1.rankingService.placeAdInRanking({
                userId: payment.user_id,
                paymentId: payment.id,
                position: payment.position,
                businessName: payment.business_name,
                targetUrl: payment.target_url,
                slogan: payment.slogan,
                category: payment.category,
                avatar: payment.avatar,
                amountPaid: Number(payment.amount_usd),
                durationHours: payment.duration_hours,
                zoneKey: payment.zone_key || 'nacional'
            });
            if (payment.user_id) {
                await supabase_1.supabase.from('notifications').insert([{
                        user_id: payment.user_id,
                        message: `¡Pago Móvil verificado! Tu anuncio '${payment.business_name}' ha sido activado en el puesto #${payment.position} del Ranking.`,
                        type: 'payment'
                    }]);
            }
            return {
                success: true,
                message: 'Pago aprobado y tarjeta activada',
                orderId,
                status: 'completed',
                adminNotes
            };
        }
        if (db_1.db.isPostgresActive) {
            const paymentRes = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1', [orderId]);
            if (paymentRes.rows.length === 0) {
                throw new Error('Orden de pago no encontrada.');
            }
            const payment = paymentRes.rows[0];
            await db_1.db.query("UPDATE payments SET status = 'completed' WHERE id::text = $1", [orderId]);
            await rankingService_1.rankingService.placeAdInRanking({
                userId: payment.user_id,
                paymentId: payment.id,
                position: payment.position,
                businessName: payment.business_name,
                targetUrl: payment.target_url,
                slogan: payment.slogan,
                category: payment.category,
                avatar: payment.avatar,
                amountPaid: Number(payment.amount_usd),
                durationHours: payment.duration_hours,
                zoneKey: payment.zone_key || 'nacional'
            });
            if (payment.user_id) {
                await db_1.db.query("INSERT INTO notifications (user_id, message, type) VALUES ($1, $2, 'payment')", [payment.user_id, `¡Pago Móvil verificado! Tu anuncio '${payment.business_name}' ha sido activado en el puesto #${payment.position} del Ranking.`]);
            }
            return {
                success: true,
                message: 'Pago aprobado y tarjeta activada',
                orderId,
                status: 'completed',
                adminNotes
            };
        }
        const store = db_1.db.getInMemoryStore();
        const payment = store.payments.find(p => p.id === orderId);
        if (!payment) {
            throw new Error('Orden de pago no encontrada.');
        }
        payment.status = 'completed';
        await rankingService_1.rankingService.placeAdInRanking({
            userId: payment.user_id,
            paymentId: payment.id,
            position: payment.position,
            businessName: payment.business_name,
            targetUrl: payment.target_url,
            slogan: payment.slogan,
            category: payment.category,
            avatar: payment.avatar,
            amountPaid: Number(payment.amount_usd),
            durationHours: payment.duration_hours,
            zoneKey: payment.zone_key || 'nacional'
        });
        return {
            success: true,
            message: 'Pago aprobado y tarjeta activada',
            orderId,
            status: 'completed',
            adminNotes
        };
    }
    /**
     * 5. Rechaza una orden de Pago Móvil
     */
    async rejectPagoMovil(orderId, adminNotes) {
        if (supabase_1.supabase) {
            const { data: payment, error: fetchErr } = await supabase_1.supabase
                .from('payments')
                .select('*')
                .eq('id', orderId)
                .maybeSingle();
            if (fetchErr)
                throw new Error(fetchErr.message);
            if (!payment) {
                throw new Error('Orden de pago no encontrada.');
            }
            const { error: updateErr } = await supabase_1.supabase
                .from('payments')
                .update({ status: 'rejected' })
                .eq('id', orderId);
            if (updateErr)
                throw new Error(updateErr.message);
            if (payment.user_id) {
                await supabase_1.supabase.from('notifications').insert([{
                        user_id: payment.user_id,
                        message: `Tu Pago Móvil para '${payment.business_name}' fue rechazado. Motivo: ${adminNotes || 'Referencia bancaria no encontrada o inválida.'}`,
                        type: 'alert'
                    }]);
            }
            return {
                success: true,
                message: 'Pago rechazado',
                orderId,
                status: 'rejected',
                adminNotes
            };
        }
        if (db_1.db.isPostgresActive) {
            const paymentRes = await db_1.db.query('SELECT * FROM payments WHERE id::text = $1', [orderId]);
            if (paymentRes.rows.length === 0) {
                throw new Error('Orden de pago no encontrada.');
            }
            const payment = paymentRes.rows[0];
            await db_1.db.query("UPDATE payments SET status = 'rejected' WHERE id::text = $1", [orderId]);
            if (payment.user_id) {
                await db_1.db.query("INSERT INTO notifications (user_id, message, type) VALUES ($1, $2, 'alert')", [payment.user_id, `Tu Pago Móvil para '${payment.business_name}' fue rechazado. Motivo: ${adminNotes || 'Referencia bancaria no encontrada o inválida.'}`]);
            }
            return {
                success: true,
                message: 'Pago rechazado',
                orderId,
                status: 'rejected',
                adminNotes
            };
        }
        const store = db_1.db.getInMemoryStore();
        const payment = store.payments.find(p => p.id === orderId);
        if (!payment) {
            throw new Error('Orden de pago no encontrada.');
        }
        payment.status = 'rejected';
        return {
            success: true,
            message: 'Pago rechazado',
            orderId,
            status: 'rejected',
            adminNotes
        };
    }
}
exports.PaymentService = PaymentService;
exports.paymentService = new PaymentService();
//# sourceMappingURL=paymentService.js.map