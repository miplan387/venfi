"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPriceForPosition = exports.getZonePricing = exports.getAllZones = exports.zonesService = exports.ZonesService = void 0;
const db_1 = require("../database/db");
class ZonesService {
    /**
     * Obtiene todas las zonas geográficas activas ordenadas
     */
    async getAllZones() {
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM zones WHERE is_active = TRUE ORDER BY sort_order ASC, id ASC');
            return res.rows.map(this.formatZone);
        }
        const store = db_1.db.getInMemoryStore();
        return (store.zones || [])
            .filter((z) => z.is_active !== false)
            .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0))
            .map(this.formatZone);
    }
    /**
     * Obtiene la estructura de precios para una zona específica
     */
    async getZonePricing(zoneKey) {
        const normalizedKey = (zoneKey || 'nacional').toLowerCase().trim();
        if (db_1.db.isPostgresActive) {
            const res = await db_1.db.query('SELECT * FROM zone_pricing WHERE zone_key = $1 AND is_active = TRUE ORDER BY position ASC', [normalizedKey]);
            if (res.rows.length > 0) {
                return res.rows.map(this.formatPricing);
            }
        }
        else {
            const store = db_1.db.getInMemoryStore();
            const pricings = (store.zone_pricing || [])
                .filter((p) => p.zone_key === normalizedKey && p.is_active !== false)
                .sort((a, b) => a.position - b.position);
            if (pricings.length > 0) {
                return pricings.map(this.formatPricing);
            }
        }
        // Fallback a zona nacional si no existe configuración específica
        if (normalizedKey !== 'nacional') {
            return this.getZonePricing('nacional');
        }
        return [];
    }
    /**
     * Obtiene el precio en USD para una posición dentro de una zona
     */
    async getPriceForPosition(zoneKey, position) {
        const pos = Math.min(Math.max(1, position), 10);
        const pricings = await this.getZonePricing(zoneKey);
        const item = pricings.find(p => p.position === pos);
        if (item) {
            return Number(item.price_usd);
        }
        // Fallback estandarizado si la posición específica no está definida en la zona
        if (pos === 1)
            return 10.00;
        if (pos === 2 || pos === 3)
            return 6.00;
        return 4.00;
    }
    formatZone(row) {
        return {
            id: Number(row.id),
            key: row.key,
            name: row.name,
            type: row.type,
            icon: row.icon || '📍',
            is_active: Boolean(row.is_active),
            sort_order: Number(row.sort_order || 0),
            created_at: row.created_at
        };
    }
    formatPricing(row) {
        return {
            id: Number(row.id),
            zone_key: row.zone_key,
            position: Number(row.position),
            tier: row.tier,
            price_usd: Number(row.price_usd),
            duration_hours: Number(row.duration_hours || 24),
            is_active: Boolean(row.is_active)
        };
    }
}
exports.ZonesService = ZonesService;
exports.zonesService = new ZonesService();
const getAllZones = () => exports.zonesService.getAllZones();
exports.getAllZones = getAllZones;
const getZonePricing = (zoneKey) => exports.zonesService.getZonePricing(zoneKey);
exports.getZonePricing = getZonePricing;
const getPriceForPosition = (zoneKey, position) => exports.zonesService.getPriceForPosition(zoneKey, position);
exports.getPriceForPosition = getPriceForPosition;
//# sourceMappingURL=zonesService.js.map