"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.visitsService = exports.VisitsService = void 0;
const db_1 = require("../database/db");
class VisitsService {
    // Mapa en memoria para rastrear actividad en ventana deslizante de 5 minutos (300,000 ms)
    activeSessions = new Map();
    ACTIVE_WINDOW_MS = 5 * 60 * 1000; // 5 minutos
    // Caché local en memoria de respaldo sincronizada con la base de datos
    fallbackStats = {
        totalVisits: 0,
        activeUsers: 1,
        lastUpdated: new Date().toISOString()
    };
    /**
     * Limpia sesiones inactivas (> 5 minutos) y calcula usuarios activos actuales en memoria
     */
    getActiveUsersCount() {
        const now = Date.now();
        for (const [id, timestamp] of this.activeSessions.entries()) {
            if (now - timestamp > this.ACTIVE_WINDOW_MS) {
                this.activeSessions.delete(id);
            }
        }
        // Al menos 1 usuario activo si el servidor está recibiendo consultas
        return Math.max(this.activeSessions.size, 1);
    }
    /**
     * Obtiene las estadísticas actuales de visitas y usuarios activos desde PostgreSQL
     */
    async getVisitsStats() {
        const activeCount = this.getActiveUsersCount();
        try {
            if (db_1.db.isPostgresActive) {
                // Asegurar que exista el registro inicial id = 1 en la tabla visits
                await db_1.db.query(`
          INSERT INTO visits (id, total_visits, active_users, last_updated)
          VALUES (1, 0, $1, NOW())
          ON CONFLICT (id) DO NOTHING
        `, [activeCount]);
                // Consultar el registro principal en PostgreSQL
                const res = await db_1.db.query('SELECT total_visits, active_users, last_updated FROM visits WHERE id = 1');
                if (res.rows.length > 0) {
                    const row = res.rows[0];
                    const totalVisits = Number(row.total_visits || 0);
                    // Actualizar active_users en PostgreSQL con el conteo en tiempo real
                    await db_1.db.query('UPDATE visits SET active_users = $1, last_updated = NOW() WHERE id = 1', [activeCount]);
                    // Sincronizar respaldo en memoria con el valor real persistido
                    this.fallbackStats.totalVisits = totalVisits;
                    this.fallbackStats.activeUsers = activeCount;
                    this.fallbackStats.lastUpdated = row.last_updated
                        ? new Date(row.last_updated).toISOString()
                        : new Date().toISOString();
                    return {
                        totalVisits,
                        activeUsers: activeCount,
                        lastUpdated: this.fallbackStats.lastUpdated
                    };
                }
            }
        }
        catch (err) {
            console.warn('⚠️ Error al consultar tabla visits en DB, usando respaldo en memoria:', err.message);
        }
        // Fallback en memoria si la BD no está disponible
        this.fallbackStats.activeUsers = activeCount;
        this.fallbackStats.lastUpdated = new Date().toISOString();
        return this.fallbackStats;
    }
    /**
     * Incrementa de manera acumulativa y persistente el total de visitas en PostgreSQL
     * UPDATE visits SET total_visits = total_visits + 1, last_updated = NOW() WHERE id = 1;
     * @param visitorId Identificador único del visitante (cookie, session o IP)
     */
    async incrementTotalVisits(visitorId = 'anon') {
        // 1. Registrar o renovar la sesión activa del visitante en memoria
        this.activeSessions.set(visitorId, Date.now());
        const activeCount = this.getActiveUsersCount();
        try {
            if (db_1.db.isPostgresActive) {
                // 2. Asegurar que la fila id = 1 exista antes de ejecutar el UPDATE
                await db_1.db.query(`
          INSERT INTO visits (id, total_visits, active_users, last_updated)
          VALUES (1, 0, $1, NOW())
          ON CONFLICT (id) DO NOTHING
        `, [activeCount]);
                // 3. Ejecutar UPDATE acumulativo y atómico en PostgreSQL
                const updateRes = await db_1.db.query(`
          UPDATE visits 
          SET total_visits = total_visits + 1,
              active_users = $1,
              last_updated = NOW()
          WHERE id = 1
          RETURNING total_visits, active_users, last_updated
        `, [activeCount]);
                if (updateRes.rows.length > 0) {
                    const row = updateRes.rows[0];
                    const totalVisits = Number(row.total_visits);
                    // Sincronizar caché de respaldo
                    this.fallbackStats.totalVisits = totalVisits;
                    this.fallbackStats.activeUsers = activeCount;
                    this.fallbackStats.lastUpdated = row.last_updated
                        ? new Date(row.last_updated).toISOString()
                        : new Date().toISOString();
                    return {
                        totalVisits,
                        activeUsers: activeCount,
                        lastUpdated: this.fallbackStats.lastUpdated
                    };
                }
            }
        }
        catch (err) {
            console.warn('⚠️ Error al incrementar visits en DB:', err.message);
        }
        // Fallback en memoria si la base de datos está offline
        this.fallbackStats.totalVisits += 1;
        this.fallbackStats.activeUsers = activeCount;
        this.fallbackStats.lastUpdated = new Date().toISOString();
        return this.fallbackStats;
    }
    /**
     * Alias de compatibilidad para endpoints existentes
     */
    async trackVisit(visitorId = 'anon') {
        return this.incrementTotalVisits(visitorId);
    }
    /**
     * Heartbeat para mantener activo a un usuario en la ventana deslizante de 5 minutos
     */
    async heartbeat(visitorId) {
        this.activeSessions.set(visitorId, Date.now());
        const activeCount = this.getActiveUsersCount();
        try {
            if (db_1.db.isPostgresActive) {
                await db_1.db.query('UPDATE visits SET active_users = $1, last_updated = NOW() WHERE id = 1', [activeCount]);
            }
        }
        catch (err) {
            // Silencioso para no saturar logs en heartbeats frecuentes
        }
        return { activeUsers: activeCount };
    }
}
exports.VisitsService = VisitsService;
exports.visitsService = new VisitsService();
//# sourceMappingURL=visitsService.js.map