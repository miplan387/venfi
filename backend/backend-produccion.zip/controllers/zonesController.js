"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zonesController = exports.ZonesController = void 0;
const zonesService_1 = require("../services/zonesService");
class ZonesController {
    /**
     * GET /api/zones
     * Obtiene la lista de zonas geográficas disponibles (Nacional, Caracas, Maracaibo, etc.)
     */
    async getZones(req, res) {
        try {
            const zones = await zonesService_1.zonesService.getAllZones();
            res.status(200).json({
                success: true,
                count: zones.length,
                data: zones
            });
        }
        catch (err) {
            console.error('[ZonesController Error]:', err);
            res.status(500).json({
                success: false,
                message: err.message || 'Error al obtener la lista de zonas'
            });
        }
    }
    /**
     * GET /api/zones/:key/pricing
     * Obtiene la estructura de precios y tiers para una zona específica
     */
    async getZonePricing(req, res) {
        try {
            const key = req.params.key || 'nacional';
            const pricing = await zonesService_1.zonesService.getZonePricing(key);
            res.status(200).json({
                success: true,
                zone: key,
                count: pricing.length,
                data: pricing
            });
        }
        catch (err) {
            console.error('[ZonesController Error]:', err);
            res.status(500).json({
                success: false,
                message: err.message || 'Error al obtener los precios de la zona'
            });
        }
    }
}
exports.ZonesController = ZonesController;
exports.zonesController = new ZonesController();
//# sourceMappingURL=zonesController.js.map